import { defineConfig, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath } from 'node:url';

const API = process.env.API_ORIGIN ?? 'http://localhost:3001';
const file = (p: string) => fileURLToPath(new URL(p, import.meta.url));

/** In development, open the admin page at /admin (the real server does the same in production). */
const adminRoute = (): Plugin => ({
  name: 'admin-route',
  configureServer(server) {
    server.middlewares.use((req, _res, next) => {
      if (req.url && /^\/admin\/?(\?.*)?$/.test(req.url)) req.url = '/admin.html';
      next();
    });
  },
});

export default defineConfig({
  plugins: [react(), adminRoute()],
  // Used by `npm run dev:full` - forwards data/API calls to the Node server.
  server: { proxy: { '/api': API, '/uploads': API } },
  build: {
    // Two pages: the customer website (index.html) and the admin panel (admin.html)
    rollupOptions: { input: { main: file('./index.html'), admin: file('./admin.html') } },
  },
});
