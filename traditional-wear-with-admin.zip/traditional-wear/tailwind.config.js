/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ivory: '#FBF6EE',
        cream: '#F4EBDD',
        beige: '#E7D9C4',
        maroon: '#6B1526',
        burgundy: '#4A0E1B',
        gold: { DEFAULT: '#B8965A', light: '#D8BC85' },
        charcoal: '#2A2426',
      },
      fontFamily: {
        display: ['"Cormorant Garamond"', 'Georgia', 'serif'],
        body: ['Manrope', 'system-ui', 'sans-serif'],
      },
      boxShadow: { soft: '0 10px 40px -14px rgba(74,14,27,0.28)' },
    },
  },
  plugins: [],
};
