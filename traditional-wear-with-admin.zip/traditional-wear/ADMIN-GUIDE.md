# Traditional Wear – Admin Panel Guide

Your website now has an admin panel at **`/admin`** (for example `https://yourshop.com/admin`, or `http://localhost:3000/admin` on your own computer).
The customer-facing website looks and works exactly as before; it just reads its products, categories and WhatsApp number from the admin data.

## 1. Start it (first time)
You need Node.js 18.17 or newer (nodejs.org). In a terminal, inside this folder:

```
npm install
npm run setup        # asks for an admin username + password, creates the .env file
npm run build        # builds the website and admin panel
npm start            # starts everything
```
Open **http://localhost:3000** (website) and **http://localhost:3000/admin** (admin).
Next time you only need `npm start` (run `npm run build` again only after changing code).

## 2. Login details
- URL: `/admin`
- Username and password: whatever you chose during `npm run setup`.
- Credentials are stored in the `.env` file (never in the website code):
  `ADMIN_USERNAME`, `ADMIN_PASSWORD_HASH` (a scrambled form of your password), `SESSION_SECRET`.
- **Change the password:** run `npm run set-password`, then restart the server. Everyone is signed out.
- After 5 wrong attempts a visitor is locked out for 15 minutes. You stay signed in for 12 hours.
- Never share or upload your `.env` file.

## 3. Add a category
Categories → **Add Category** → type the name, choose a photo → Save. It appears in "Shop by Category" and in the shop filters.
You can rename a category, change its photo, re-order the cards (arrows), and see which products are inside ("Show products in this category").
A category can only be deleted when it has no products. "New Arrivals" is a special section: you can rename it or change its photo but not delete it.
Note: the website's top menu/footer link to *Ethnic Dresses*, *Traditional Wear* and *Festive Collection*; the admin warns you before deleting those.

## 4. Add a product
Products → **Add Product** (or "Add product" inside a category):
1. Name, category, description
2. Price (and optionally an "old price" for a sale – the % off is worked out for you)
3. Photos – tap *Add photos* (camera or gallery). The first photo is the main one; use the arrows to re-order, the circular arrows to replace, the bin to remove. Up to 8 photos, JPG/PNG/WebP, 10 MB each.
4. Colours – tap a colour chip, or "Other colour" to pick your own
5. Sizes – tap the sizes; add custom ones (e.g. 38)
6. Show on website – Available to buy, New Arrivals, Customer Favourites, photo label (NEW / BEST SELLER / SALE)

Press **Save Product**. It is live on the website straight away – newest products appear first in New Arrivals / Customer Favourites.
Required: name, category, a valid price, at least 1 photo, 1 size and 1 colour.

## 5. Edit prices, sizes and colours
Products → **Edit** on the product → change anything → Save.
- **Different price for some sizes:** tick "Some sizes have a different price" and fill in only those sizes. Customers see the price change when they pick the size; the cart and the WhatsApp order use it. (Colours cannot have their own price.)
- **Sold out:** use the switch on the product list (or in the form). The product stays visible with "SOLD OUT" and cannot be ordered.

## 6. Change the WhatsApp number
Settings → enter the number with country code, no spaces (India: `919876543210`) → Save number. Use the *Test this number* link to check it.
It updates the green chat button, the footer links and the "Order on WhatsApp" button.

## 7. Where data and photos are stored
- `data/store.json` – products, categories, WhatsApp number (`store.json.bak` is the previous version, kept automatically)
- `data/uploads/` – uploaded photos
**Back up the whole `data` folder regularly.** To keep it elsewhere, set `DATA_DIR` (see below).

## 8. Environment variables (`.env` or your host's settings page)
| Variable | Needed? | Meaning |
|---|---|---|
| `ADMIN_USERNAME` | yes | admin login name |
| `ADMIN_PASSWORD_HASH` | yes | created by `npm run setup` / `npm run set-password` |
| `SESSION_SECRET` | yes | long random text (32+ characters), created by `npm run setup` |
| `PORT` | no | default 3000 (most hosts set it automatically) |
| `DATA_DIR` | no | folder for data + photos, default `./data` – point to a persistent disk online |
| `TRUST_PROXY` | online | set `1` when behind Nginx / Render / Railway / Cloudflare |
| `SESSION_HOURS` | no | stay-signed-in time, default 12 |

If your host has a settings page instead of a `.env` file, run `npm run setup` on your computer, then copy the three printed variables there.

## 9. Deploy the admin together with the website
The website and admin are **one Node app** (`npm run build`, then `npm start`). Because admin changes and photos must be saved, you need hosting that **runs Node and keeps its files**:
- **A VPS** (DigitalOcean, Lightsail, EC2, Hostinger…): upload the project, `npm install`, `npm run setup`, `npm run build`, run `npm start` with PM2, and put Nginx + HTTPS (Let's Encrypt) in front. Set `TRUST_PROXY=1`.
- **Render / Railway / Fly.io:** build command `npm install && npm run build`, start command `npm start`, add a **persistent disk/volume** and set `DATA_DIR` to its path, add the three admin variables and `TRUST_PROXY=1`.
- **Not suitable:** Netlify / Vercel drag-and-drop or any static-only host – their files are wiped on each deploy and there is no server for the admin. (The site still works there from its built-in sample data, but without admin.)
Always use HTTPS online so your login is encrypted.

## Developer notes
- `npm run dev:full` runs the API (port 3001) and Vite (port 5173) together; use http://localhost:5173/admin.
- Admin code: `admin-ui/`. Server: `server/`. Website data hook: `src/data/catalog.ts` (falls back to the built-in `products.ts` / `categories.ts` if no server data exists).
- Other site images (hero, festive banner, Instagram gallery) are still in `src/data/images.ts`.
- Email / Instagram / Facebook are still edited in `src/config.ts`.
