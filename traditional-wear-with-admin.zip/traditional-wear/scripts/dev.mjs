// Developer convenience: runs the API server (port 3001) and the Vite dev server (port 5173) together.
// Open http://localhost:5173 for the website and http://localhost:5173/admin for the admin panel.
import { spawn } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const run = (args, env = {}) => spawn(process.execPath, args, { cwd: ROOT, stdio: 'inherit', env: { ...process.env, ...env } });

const api = run(['--watch', 'server/index.js'], { PORT: '3001' });
const web = run([path.join('node_modules', 'vite', 'bin', 'vite.js')]);
const stop = () => { api.kill(); web.kill(); };
process.on('SIGINT', stop); process.on('SIGTERM', stop);
api.on('exit', (c) => { if (c) { web.kill(); process.exit(c); } });
web.on('exit', () => { api.kill(); process.exit(0); });
