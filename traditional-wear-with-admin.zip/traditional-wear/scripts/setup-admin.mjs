#!/usr/bin/env node
// Creates / updates the admin login in the .env file.
//   npm run setup          -> choose username + password (first time)
//   npm run set-password   -> change the password only
// Optional (non-interactive):  node scripts/setup-admin.mjs --username admin --password "my long password"
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import readline from 'node:readline';
import { fileURLToPath } from 'node:url';
import { hashPassword, MIN_PASSWORD_LENGTH } from '../server/password.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const ENV_FILE = path.join(ROOT, '.env');
const args = process.argv.slice(2);
const flag = (name) => { const i = args.indexOf(`--${name}`); return i >= 0 ? args[i + 1] : undefined; };
const passwordOnly = args.includes('--password-only');

const read = () => (fs.existsSync(ENV_FILE) ? fs.readFileSync(ENV_FILE, 'utf8') : '');
const getVar = (text, key) => (text.match(new RegExp(`^${key}=(.*)$`, 'm')) || [])[1]?.trim();
function setVar(text, key, value) {
  const line = `${key}=${value}`;
  const re = new RegExp(`^${key}=.*$`, 'm');
  return re.test(text) ? text.replace(re, () => line) : `${text}${text && !text.endsWith('\n') ? '\n' : ''}${line}\n`;
}
const removeVar = (text, key) => text.replace(new RegExp(`^${key}=.*\\n?`, 'm'), '');

function ask(question, { hidden = false } = {}) {
  return new Promise((resolve) => {
    if (!hidden || !process.stdin.isTTY) {
      const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
      rl.question(question, (a) => { rl.close(); resolve(a); });
      return;
    }
    process.stdout.write(question);
    const stdin = process.stdin;
    stdin.setRawMode(true); stdin.resume(); stdin.setEncoding('utf8');
    let buf = '';
    const onData = (chunk) => {
      for (const ch of chunk) {
        if (ch === '\r' || ch === '\n' || ch === '\u0004') { stdin.setRawMode(false); stdin.pause(); stdin.off('data', onData); process.stdout.write('\n'); return resolve(buf); }
        if (ch === '\u0003') { process.stdout.write('\n'); process.exit(1); }
        if (ch === '\u007f' || ch === '\b') buf = buf.slice(0, -1);
        else buf += ch;
      }
    };
    stdin.on('data', onData);
  });
}

let env = read();
let username = flag('username') ?? getVar(env, 'ADMIN_USERNAME');

console.log('\nTraditional Wear - admin login setup\n');

if (!passwordOnly && !flag('username')) {
  const answer = (await ask(`Admin username [${username || 'admin'}]: `)).trim();
  username = answer || username || 'admin';
}
if (!username) { console.error('No admin username found. Run "npm run setup" first.'); process.exit(1); }
if (!/^[A-Za-z0-9._@-]{3,40}$/.test(username)) { console.error('Username: 3-40 characters, letters, numbers and . _ @ - only.'); process.exit(1); }

let password = flag('password');
if (!password) {
  for (let attempt = 0; attempt < 3 && !password; attempt += 1) {
    const p1 = await ask(`New password (at least ${MIN_PASSWORD_LENGTH} characters): `, { hidden: true });
    if (p1.length < MIN_PASSWORD_LENGTH) { console.log(`Too short - use at least ${MIN_PASSWORD_LENGTH} characters.\n`); continue; }
    const p2 = await ask('Type it again: ', { hidden: true });
    if (p1 !== p2) { console.log("The two passwords don't match.\n"); continue; }
    password = p1;
  }
}
if (!password || password.length < MIN_PASSWORD_LENGTH) { console.error(`Password must be at least ${MIN_PASSWORD_LENGTH} characters. Nothing was changed.`); process.exit(1); }

const hash = await hashPassword(password);
let secret = getVar(env, 'SESSION_SECRET');
if (!secret || secret.length < 32) secret = crypto.randomBytes(48).toString('hex');

env = setVar(env, 'ADMIN_USERNAME', username);
env = setVar(env, 'ADMIN_PASSWORD_HASH', hash);
env = setVar(env, 'SESSION_SECRET', secret);
env = removeVar(env, 'ADMIN_PASSWORD'); // never keep a plain-text password around
fs.writeFileSync(ENV_FILE, env, { mode: 0o600 });

console.log(`\nSaved to ${ENV_FILE}`);
console.log('Restart the server (stop it and run "npm start" again) for the change to take effect.');
console.log('Everyone who was signed in will have to sign in again.\n');
console.log('Hosting with a settings dashboard instead of a .env file (Render, Railway, ...)?');
console.log('Add these three variables there:\n');
console.log(`  ADMIN_USERNAME=${username}`);
console.log(`  ADMIN_PASSWORD_HASH=${hash}`);
console.log(`  SESSION_SECRET=${secret}\n`);
