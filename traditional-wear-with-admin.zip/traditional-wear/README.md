# Traditional Wear – online store

> **Admin panel added.** Products, categories, photos, prices, sizes, colours and the WhatsApp number are now managed at `/admin`.
> See **ADMIN-GUIDE.md** for setup (`npm install`, `npm run setup`, `npm run build`, `npm start`) and deployment.
> Sections 1–4 below describe the old edit-the-code method; it only applies as a fallback if the admin server is not used.


React + TypeScript + Tailwind CSS (built with Vite). No other libraries.

## Run it on your computer
1. Install Node.js (version 18 or newer) from nodejs.org
2. Open a terminal in this folder and run:
   ```
   npm install
   npm run dev
   ```
3. Open the address it prints (usually http://localhost:5173)

## 1. Replace product images
All pictures are listed in `src/data/images.ts`. Right now they are illustrated placeholders.
- Put your photos in the `public/images/` folder (create it), e.g. `public/images/anarkali.jpg`
- In `src/data/images.ts`, change the value to `'/images/anarkali.jpg'`
- Or, in `src/data/products.ts`, set a product's `image: '/images/anarkali.jpg'` directly
- Best size for product photos: portrait 3:4 (about 900 x 1200 px). Compress them (squoosh.app) to keep the site fast.

## 2. Add or remove products
Open `src/data/products.ts`.
- **Add:** copy one product block, paste it at the end of the list, give it a new unique `id`, and edit the name, category, price, description, sizes and colours.
- **Remove:** delete that product's block.
- `newArrival: true` shows it under NEW ARRIVALS (first 4 are shown). `bestSeller: true` shows it under CUSTOMER FAVOURITES (first 6).
- `category` must be `'ethnic-dresses'`, `'traditional-wear'`, `'festive'`, `'party-wear'` or `'everyday'`.

## 3. Change prices
In `src/data/products.ts` edit `price`. For a sale, also set `originalPrice` (the old price) and `discount` (the percent off, e.g. `15`). To end a sale, delete `originalPrice` and `discount`.
The price filter ranges are in `src/data/categories.ts` (`PRICE_RANGES`).

## 4. Change the WhatsApp number
Open `src/config.ts` and set `WHATSAPP_NUMBER` with country code and digits only, e.g. `'919876543210'`.
This powers the floating chat button, the footer links and the "Order on WhatsApp" button in the cart.

## 5. Change Instagram / Facebook links
In `src/config.ts` set `INSTAGRAM_URL` and `FACEBOOK_URL`. If `INSTAGRAM_URL` is left as-is, the link is built automatically from `INSTAGRAM`. Also set `EMAIL` there.

## 6. Deploy (static, no admin)
For the version WITH the admin panel, follow ADMIN-GUIDE.md instead (needs a Node host with persistent storage).
Run `npm run build`. This creates a `dist/` folder – that is your finished website.
Easiest free options:
- **Netlify:** go to app.netlify.com/drop and drag the `dist` folder onto the page. You get a live link in seconds.
- **Vercel / Cloudflare Pages:** connect a GitHub repo; build command `npm run build`, output folder `dist`.
Connect your own domain (e.g. traditionalwear.in) from the hosting dashboard.

## Before you go live
- Replace the sample reviews in `src/components/Testimonials.tsx` and sample ratings in `products.ts` with real ones.
- Read the answers in `src/components/FAQ.tsx` and make sure they match your real delivery, COD and return policies.
- The newsletter form validates the email but does not store it yet – connect a service (Mailchimp, Brevo, Formspree) in `src/components/Newsletter.tsx` (see the TODO).
- Policy pages in the footer show "coming soon" until you create them.
- Add `public/og-image.jpg` (1200 x 630) so links look good when shared.
- Checkout: the cart sends the order to your WhatsApp. To take online payments later, connect Razorpay or Shopify Buy Button.
