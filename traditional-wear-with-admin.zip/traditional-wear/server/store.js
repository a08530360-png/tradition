// The "database": one JSON file (data/store.json) + a folder of photos. Writes are serialised and atomic.
import fs from 'node:fs/promises';
import path from 'node:path';
import { DATA_DIR, UPLOAD_DIR, ROOT } from './config.js';
import { sweepUploads } from './images.js';

const FILE = path.join(DATA_DIR, 'store.json');
let state = null;
let queue = Promise.resolve();

export async function initStore() {
  await fs.mkdir(UPLOAD_DIR, { recursive: true });
  try {
    state = JSON.parse(await fs.readFile(FILE, 'utf8'));
  } catch (err) {
    if (err.code !== 'ENOENT') {
      // Unreadable file: try the automatic backup before anything else.
      try {
        state = JSON.parse(await fs.readFile(`${FILE}.bak`, 'utf8'));
        console.warn('[store] store.json was unreadable - restored from store.json.bak');
      } catch {
        throw new Error(`Cannot read ${FILE}. Fix or delete it (a backup copy may exist as store.json.bak).`);
      }
    } else {
      state = JSON.parse(await fs.readFile(path.join(ROOT, 'server', 'seed.json'), 'utf8'));
      await persist(state);
      console.log('[store] First start: created data/store.json from your existing website products.');
    }
  }
  state.settings ||= { whatsappNumber: '' };
  state.categories ||= [];
  state.products ||= [];
  state.nextProductId ||= Math.max(0, ...state.products.map((p) => p.id)) + 1;
  await cleanup();
}

export const getState = () => state;

async function persist(next) {
  const tmp = `${FILE}.tmp`;
  await fs.writeFile(tmp, JSON.stringify(next, null, 2));
  try { await fs.copyFile(FILE, `${FILE}.bak`); } catch { /* first write */ }
  await fs.rename(tmp, FILE);
}

/** Run a change. `fn` receives a copy of the data, edits it, and may throw to cancel (nothing is saved then). */
export function mutate(fn) {
  const run = queue.then(async () => {
    const draft = structuredClone(state);
    const result = await fn(draft);
    await persist(draft);
    state = draft;
    cleanup().catch(() => {});
    return result;
  });
  queue = run.catch(() => {});
  return run;
}

export async function cleanup() {
  const refs = new Set([
    ...state.categories.map((c) => c.image),
    ...state.products.flatMap((p) => p.images || [p.image]),
  ]);
  await sweepUploads(refs);
}

/** What the public website is allowed to see. */
export function publicView() {
  return {
    settings: { whatsappNumber: state.settings.whatsappNumber || '' },
    categories: state.categories,
    products: state.products,
  };
}
