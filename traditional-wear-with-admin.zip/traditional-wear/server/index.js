// Traditional Wear server: serves the existing website + the admin panel + the data API.
import express from 'express';
import compression from 'compression';
import fs from 'node:fs/promises';
import path from 'node:path';
import { PORT, DIST_DIR, UPLOAD_DIR, DATA_DIR, TRUST_PROXY } from './config.js';
import { initStore, publicView } from './store.js';
import { initAuth, isConfigured } from './auth.js';
import adminRoutes from './admin-routes.js';
import { HttpError } from './validate.js';

await initStore();
await initAuth();

const app = express();
app.disable('x-powered-by');
if (TRUST_PROXY) app.set('trust proxy', TRUST_PROXY);

// Safe defaults for every response
app.use((_req, res, next) => {
  res.set({
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'X-Frame-Options': 'SAMEORIGIN',
  });
  next();
});
app.use(compression());

// Express 4 does not catch errors from async handlers by itself - this wrapper does.
const wrapAsync = (router) => {
  for (const layer of router.stack) {
    if (layer.route) for (const l of layer.route.stack) { const h = l.handle; if (h.length < 4) l.handle = (req, res, next) => Promise.resolve(h(req, res, next)).catch(next); }
  }
  return router;
};

// ---- API ----------------------------------------------------------------------------------------------------
app.get('/api/store', (_req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json(publicView());
});
app.use('/api/admin', wrapAsync(adminRoutes));
app.use('/api', (_req, _res, next) => next(new HttpError(404, 'Not found.')));

// ---- Uploaded photos (random file names, so they can be cached for a long time) --------------------------------------
app.use('/uploads', express.static(UPLOAD_DIR, { index: false, dotfiles: 'deny', maxAge: '30d', immutable: true, fallthrough: false }));

// ---- Website + admin pages -----------------------------------------------------------------------------------------
const hasBuild = async () => fs.access(path.join(DIST_DIR, 'index.html')).then(() => true, () => false);
const NEEDS_BUILD = 'The website has not been built yet. Run "npm run build" and then restart the server.';

const safeJson = (obj) => JSON.stringify(obj).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');

async function sendSite(_req, res) {
  if (!(await hasBuild())) return res.status(503).type('text').send(NEEDS_BUILD);
  const html = await fs.readFile(path.join(DIST_DIR, 'index.html'), 'utf8');
  // Embed the current products/categories/WhatsApp number straight into the page: instant load, no flicker.
  const out = html.replace(/(<script id="store-data" type="application\/json">)[\s\S]*?(<\/script>)/, (_m, a, b) => `${a}${safeJson(publicView())}${b}`);
  res.set('Cache-Control', 'no-cache').type('html').send(out);
}

async function sendAdmin(_req, res) {
  if (!(await hasBuild())) return res.status(503).type('text').send(NEEDS_BUILD);
  res.set({
    'Cache-Control': 'no-store',
    'X-Robots-Tag': 'noindex, nofollow',
    'X-Frame-Options': 'DENY',
    'Content-Security-Policy': "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
  });
  res.sendFile(path.join(DIST_DIR, 'admin.html'));
}

app.get('/admin', sendAdmin);
app.get('/admin/', sendAdmin);
app.get('/admin/*', (_req, res) => res.redirect(302, '/admin'));
app.get(['/index.html'], (_req, res) => res.redirect(301, '/'));
app.get(['/admin.html'], (_req, res) => res.redirect(301, '/admin'));
app.get('/robots.txt', (_req, res) => res.type('text').send('User-agent: *\nDisallow: /admin\nDisallow: /api/\n'));

app.use(express.static(DIST_DIR, { index: false, maxAge: '1h', setHeaders: (res, file) => { if (file.includes(`${path.sep}assets${path.sep}`)) res.set('Cache-Control', 'public, max-age=31536000, immutable'); } }));
app.get('*', sendSite);

// ---- Errors ----------------------------------------------------------------------------------------------------
app.use((err, _req, res, _next) => {
  if (!(err instanceof HttpError) && (err.status === 404 || err.statusCode === 404)) return res.status(404).json({ error: 'Not found.' }); // e.g. a missing /uploads file
  if (err instanceof HttpError) return res.status(err.status).json({ error: err.message, fields: err.fields });
  if (err.type === 'entity.parse.failed' || err.type === 'entity.too.large') return res.status(400).json({ error: 'Invalid request.' });
  const status = err.status || err.statusCode;
  if (status >= 400 && status < 500) return res.status(status).json({ error: 'Invalid request.' }); // e.g. blocked path tricks
  console.error('[error]', err);
  res.status(500).json({ error: 'Something went wrong on the server. Please try again.' });
});

app.listen(PORT, () => {
  console.log(`\n  Traditional Wear is running`);
  console.log(`  Website : http://localhost:${PORT}/`);
  console.log(`  Admin   : http://localhost:${PORT}/admin  ${isConfigured() ? '' : '(login disabled - run "npm run setup")'}`);
  console.log(`  Data    : ${DATA_DIR}\n`);
});
