// Central place for every setting the server reads from the environment (.env file or hosting dashboard).
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
dotenv.config({ path: path.join(ROOT, '.env') });

const env = process.env;

export const PORT = Number(env.PORT) || 3000;

// Where products, categories, settings and uploaded photos live. Point this at a persistent disk in production.
export const DATA_DIR = path.resolve(ROOT, env.DATA_DIR || 'data');
export const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
export const DIST_DIR = path.join(ROOT, 'dist');

export const ADMIN_USERNAME = (env.ADMIN_USERNAME || '').trim();
export const ADMIN_PASSWORD_HASH = (env.ADMIN_PASSWORD_HASH || '').trim();
export const ADMIN_PASSWORD = env.ADMIN_PASSWORD || ''; // optional plain-text alternative (less safe)
export const SESSION_SECRET = (env.SESSION_SECRET || '').trim();
export const SESSION_HOURS = Number(env.SESSION_HOURS) > 0 ? Number(env.SESSION_HOURS) : 12;

// Set TRUST_PROXY=1 when the app runs behind Nginx / Render / Railway / Cloudflare etc.
const tp = (env.TRUST_PROXY || '').trim();
export const TRUST_PROXY = tp === '' ? false : /^\d+$/.test(tp) ? Number(tp) : tp === 'true' ? true : tp;

// Optional extra origins allowed to call the admin API (comma separated). Normally not needed.
export const ALLOWED_ORIGINS = (env.ALLOWED_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean);
