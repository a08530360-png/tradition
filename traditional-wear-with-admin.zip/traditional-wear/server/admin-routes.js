// All /api/admin/* endpoints. Everything except login/session/logout requires a signed-in admin.
import express from 'express';
import multer from 'multer';
import { requireAdmin, csrfGuard, login, logout, currentSession, isConfigured, configProblem } from './auth.js';
import { getState, mutate } from './store.js';
import { saveImage } from './images.js';
import {
  HttpError, LIMITS, MENU_LINKED, SYSTEM_CATEGORY,
  validateProduct, validateCategory, validateSettings, makeSlug,
} from './validate.js';

const router = express.Router();
router.use((_req, res, next) => { res.set('Cache-Control', 'no-store'); next(); });
router.use(express.json({ limit: '300kb' }));
router.use(csrfGuard);

// ---- Session -------------------------------------------------------------------------------------------------
router.get('/session', (req, res) => {
  const s = currentSession(req);
  res.json({ configured: isConfigured(), problem: isConfigured() ? '' : configProblem(), authenticated: !!s, username: s?.u || null });
});
router.post('/login', async (req, res) => { await login(req, res); res.json({ ok: true }); });
router.post('/logout', (req, res) => { logout(req, res); res.json({ ok: true }); });

// ---- Everything below needs a login ---------------------------------------------------------------------------
router.use(requireAdmin);

const view = () => {
  const s = getState();
  return {
    settings: s.settings,
    categories: s.categories.map((c) => ({ ...c, menuLinked: MENU_LINKED.has(c.id) })),
    products: s.products,
  };
};
router.get('/data', (_req, res) => res.json(view()));

// ---- Photo upload -----------------------------------------------------------------------------------------------
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024, files: LIMITS.maxImages } });
router.post('/upload', (req, res, next) => {
  upload.array('files', LIMITS.maxImages)(req, res, async (err) => {
    try {
      if (err) {
        if (err.code === 'LIMIT_FILE_SIZE') throw new HttpError(413, 'A photo is too large (maximum 10 MB each).');
        if (err.code === 'LIMIT_FILE_COUNT' || err.code === 'LIMIT_UNEXPECTED_FILE') throw new HttpError(400, `You can upload up to ${LIMITS.maxImages} photos at a time.`);
        throw new HttpError(400, 'Upload failed. Please try again.');
      }
      if (!req.files?.length) throw new HttpError(400, 'No photo was received.');
      const urls = [];
      for (const f of req.files) urls.push(await saveImage(f.buffer));
      res.json({ urls });
    } catch (e) { next(e); }
  });
});

// ---- Categories -------------------------------------------------------------------------------------------------
router.post('/categories', async (req, res) => {
  await mutate((s) => {
    if (s.categories.length >= LIMITS.maxCategories) throw new HttpError(400, `You can have up to ${LIMITS.maxCategories} categories.`);
    const { name, image } = validateCategory(req.body, s);
    s.categories.push({ id: makeSlug(name, s), name, image });
  });
  res.json(view());
});

// Must be declared before '/categories/:id'
router.post('/categories/reorder', async (req, res) => {
  const order = Array.isArray(req.body?.order) ? req.body.order : [];
  await mutate((s) => {
    const ids = s.categories.map((c) => c.id);
    if (order.length !== ids.length || !ids.every((id) => order.includes(id))) throw new HttpError(400, 'The list changed. Please refresh and try again.');
    s.categories = order.map((id) => s.categories.find((c) => c.id === id));
  });
  res.json(view());
});

router.put('/categories/:id', async (req, res) => {
  await mutate((s) => {
    const cat = s.categories.find((c) => c.id === req.params.id);
    if (!cat) throw new HttpError(404, 'Category not found.');
    Object.assign(cat, validateCategory(req.body, s, cat)); // the internal id (slug) never changes, so products stay linked
  });
  res.json(view());
});

router.delete('/categories/:id', async (req, res) => {
  await mutate((s) => {
    const cat = s.categories.find((c) => c.id === req.params.id);
    if (!cat) throw new HttpError(404, 'Category not found.');
    if (cat.id === SYSTEM_CATEGORY) throw new HttpError(400, '"New Arrivals" is a special section and cannot be deleted. You can rename it or change its photo.');
    const count = s.products.filter((p) => p.category === cat.id).length;
    if (count > 0) throw new HttpError(409, `This category still has ${count} product${count === 1 ? '' : 's'}. Move or delete them first.`);
    s.categories = s.categories.filter((c) => c.id !== cat.id);
  });
  res.json(view());
});

// ---- Products ---------------------------------------------------------------------------------------------------
router.post('/products', async (req, res) => {
  let created;
  await mutate((s) => {
    const fields = validateProduct(req.body, s);
    created = { id: s.nextProductId, ...fields };
    s.nextProductId += 1;
    s.products.unshift(created); // newest first, so it shows up at the top of New Arrivals / Customer Favourites
  });
  res.json({ ...view(), product: created });
});

router.put('/products/:id', async (req, res) => {
  const id = Number(req.params.id);
  let updated;
  await mutate((s) => {
    const i = s.products.findIndex((p) => p.id === id);
    if (i < 0) throw new HttpError(404, 'Product not found.');
    updated = { id, ...validateProduct(req.body, s, s.products[i]) };
    s.products[i] = updated;
  });
  res.json({ ...view(), product: updated });
});

router.patch('/products/:id/availability', async (req, res) => {
  const id = Number(req.params.id);
  if (typeof req.body?.available !== 'boolean') throw new HttpError(400, 'Invalid request.');
  await mutate((s) => {
    const p = s.products.find((x) => x.id === id);
    if (!p) throw new HttpError(404, 'Product not found.');
    p.available = req.body.available;
  });
  res.json(view());
});

router.delete('/products/:id', async (req, res) => {
  const id = Number(req.params.id);
  await mutate((s) => {
    if (!s.products.some((p) => p.id === id)) throw new HttpError(404, 'Product not found.');
    s.products = s.products.filter((p) => p.id !== id);
  });
  res.json(view());
});

// ---- Website settings -------------------------------------------------------------------------------------------
router.put('/settings', async (req, res) => {
  await mutate((s) => { Object.assign(s.settings, validateSettings(req.body)); });
  res.json(view());
});

export default router;
