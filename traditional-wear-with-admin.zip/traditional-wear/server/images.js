// Validates uploaded photos by their real content (not just the file name), shrinks them and stores them.
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { UPLOAD_DIR } from './config.js';
import { HttpError } from './validate.js';

let sharp = null;
try {
  sharp = (await import('sharp')).default;
} catch {
  console.warn('[images] "sharp" is not available - photos will be stored as uploaded (not resized).');
}

/** Detects JPEG / PNG / WebP from the first bytes of the file. */
export function detectType(buf) {
  if (buf.length < 12) return null;
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'jpg';
  if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'png';
  if (buf.subarray(0, 4).toString('latin1') === 'RIFF' && buf.subarray(8, 12).toString('latin1') === 'WEBP') return 'webp';
  return null;
}

export async function saveImage(buf) {
  const type = detectType(buf);
  if (!type) throw new HttpError(400, 'Only JPG, PNG or WebP photos are allowed.');

  let out = buf;
  let ext = type;
  if (sharp) {
    try {
      out = await sharp(buf, { limitInputPixels: 80_000_000 })
        .rotate() // respect phone orientation, then strip location/EXIF data
        .resize({ width: 1200, height: 1600, fit: 'inside', withoutEnlargement: true })
        .flatten({ background: '#ffffff' })
        .jpeg({ quality: 82, mozjpeg: true })
        .toBuffer();
      ext = 'jpg';
    } catch {
      throw new HttpError(400, 'That file could not be read as a photo. Please try a different image.');
    }
  }
  const file = `${crypto.randomBytes(16).toString('hex')}.${ext}`;
  await fs.writeFile(path.join(UPLOAD_DIR, file), out, { flag: 'wx' });
  return `/uploads/${file}`;
}

/** Deletes uploaded files nothing refers to any more (only files older than 1 hour, so pending uploads are safe). */
export async function sweepUploads(referenced, minAgeMs = 3600_000) {
  let names = [];
  try { names = await fs.readdir(UPLOAD_DIR); } catch { return; }
  const now = Date.now();
  await Promise.all(
    names.map(async (name) => {
      if (referenced.has(`/uploads/${name}`)) return;
      try {
        const full = path.join(UPLOAD_DIR, name);
        const st = await fs.stat(full);
        if (st.isFile() && now - st.mtimeMs > minAgeMs) await fs.unlink(full);
      } catch { /* ignore */ }
    }),
  );
}
