// All server-side validation. The admin form checks the same things, but this is the authoritative gate.
import fs from 'node:fs';
import path from 'node:path';
import { UPLOAD_DIR } from './config.js';

export class HttpError extends Error {
  constructor(status, message, fields) {
    super(message);
    this.status = status;
    this.fields = fields;
  }
}

// These categories are linked from the website's menu/footer (Navbar.tsx / Footer.tsx).
export const MENU_LINKED = new Set(['ethnic-dresses', 'traditional-wear', 'festive']);
export const SYSTEM_CATEGORY = 'new-arrivals';
const RESERVED_SLUGS = new Set(['all', SYSTEM_CATEGORY]);

const BADGES = new Set(['NEW', 'BEST SELLER', 'SALE']);
const UPLOAD_URL = /^\/uploads\/[a-f0-9]{32}\.(jpg|png|webp)$/;
const HEX = /^#[0-9a-fA-F]{6}$/;

export const LIMITS = { maxImages: 8, maxSizes: 14, maxColors: 12, maxPrice: 1_000_000, maxCategories: 40 };

const oneLine = (v) => (typeof v === 'string' ? v.replace(/\s+/g, ' ').trim() : '');
const multiLine = (v) => (typeof v === 'string' ? v.replace(/\r\n/g, '\n').trim() : '');

/** '' / null -> null, otherwise a Number (maybe NaN). Accepts "1,499" and "₹1499". */
function toNumber(v) {
  if (v === '' || v === null || v === undefined) return null;
  if (typeof v === 'number') return v;
  return Number(String(v).replace(/[,₹\s]/g, ''));
}
const isWholePrice = (n) => Number.isInteger(n) && n >= 1 && n <= LIMITS.maxPrice;

/** Data-URI images that already exist in the store (the sample illustrations) may be kept as they are. */
export const inlineImagesIn = (state) =>
  new Set([...state.products.flatMap((p) => p.images || [p.image]), ...state.categories.map((c) => c.image)].filter((u) => typeof u === 'string' && u.startsWith('data:image/')));

function imageProblem(url, knownInline) {
  if (typeof url !== 'string') return 'Invalid image.';
  if (UPLOAD_URL.test(url)) return fs.existsSync(path.join(UPLOAD_DIR, path.basename(url))) ? '' : 'An image file is missing. Please upload it again.';
  return knownInline.has(url) ? '' : 'Invalid image. Please upload the photo again.';
}

function fail(fields) {
  throw new HttpError(400, 'Please fix the highlighted fields.', fields);
}

// ------------------------------------------------------------------------------------------------------------
export function validateProduct(input, state, existing) {
  const errors = {};
  const data = input && typeof input === 'object' ? input : {};

  const name = oneLine(data.name);
  if (!name) errors.name = 'Enter the product name.';
  else if (name.length < 2 || name.length > 120) errors.name = 'Product name must be 2 to 120 characters.';

  const category = typeof data.category === 'string' ? data.category : '';
  const cat = state.categories.find((c) => c.id === category);
  if (!category) errors.category = 'Choose a category.';
  else if (!cat || cat.system) errors.category = 'That category does not exist. Choose another.';

  const price = toNumber(data.price);
  if (price === null) errors.price = 'Enter the price.';
  else if (!isWholePrice(price)) errors.price = `Enter a whole-number price between 1 and ${LIMITS.maxPrice.toLocaleString('en-IN')} (for example 1499).`;

  let originalPrice = toNumber(data.originalPrice);
  if (originalPrice !== null) {
    if (!isWholePrice(originalPrice)) errors.originalPrice = 'Enter a whole-number price, or leave it empty.';
    else if (!errors.price && originalPrice <= price) errors.originalPrice = 'The old price must be higher than the selling price.';
  } else originalPrice = undefined;

  const description = multiLine(data.description);
  if (description.length > 2000) errors.description = 'Description is too long (maximum 2000 characters).';

  // Images
  const known = inlineImagesIn(state);
  const images = Array.isArray(data.images) ? data.images : [];
  if (images.length === 0) errors.images = 'Add at least one photo.';
  else if (images.length > LIMITS.maxImages) errors.images = `You can add up to ${LIMITS.maxImages} photos.`;
  else if (new Set(images).size !== images.length) errors.images = 'The same photo was added twice.';
  else {
    const bad = images.map((u) => imageProblem(u, known)).find(Boolean);
    if (bad) errors.images = bad;
  }

  // Sizes
  const rawSizes = Array.isArray(data.sizes) ? data.sizes.map(oneLine) : [];
  const sizes = [];
  for (const s of rawSizes) if (s && !sizes.some((x) => x.toLowerCase() === s.toLowerCase())) sizes.push(s);
  if (sizes.length === 0) errors.sizes = 'Choose at least one size (use "Free Size" if the product has one size).';
  else if (sizes.length > LIMITS.maxSizes) errors.sizes = `Too many sizes (maximum ${LIMITS.maxSizes}).`;
  else if (sizes.some((s) => s.length > 14)) errors.sizes = 'A size name is too long (maximum 14 characters).';

  // Size prices (optional)
  const sizePrices = {};
  if (data.sizePrices && typeof data.sizePrices === 'object' && !errors.sizes) {
    for (const [size, raw] of Object.entries(data.sizePrices)) {
      if (!sizes.includes(size)) continue;
      const n = toNumber(raw);
      if (n === null) continue;
      if (!isWholePrice(n)) { errors.sizePrices = `Check the price for size ${size}: enter a whole number.`; break; }
      if (n !== price) sizePrices[size] = n;
    }
  }

  // Colors
  const rawColors = Array.isArray(data.colors) ? data.colors : [];
  const colors = [];
  let colorError = '';
  for (const c of rawColors) {
    const cname = oneLine(c?.name);
    const hex = typeof c?.hex === 'string' ? c.hex.trim() : '';
    if (!cname) { colorError = 'Every colour needs a name.'; break; }
    if (cname.length > 30) { colorError = 'A colour name is too long (maximum 30 characters).'; break; }
    if (!HEX.test(hex)) { colorError = `Pick a valid colour for "${cname}".`; break; }
    if (colors.some((x) => x.name.toLowerCase() === cname.toLowerCase())) { colorError = `The colour "${cname}" is listed twice.`; break; }
    colors.push({ name: cname, hex: hex.toUpperCase() });
  }
  if (colorError) errors.colors = colorError;
  else if (colors.length === 0) errors.colors = 'Add at least one colour.';
  else if (colors.length > LIMITS.maxColors) errors.colors = `Too many colours (maximum ${LIMITS.maxColors}).`;

  const badge = typeof data.badge === 'string' && BADGES.has(data.badge) ? data.badge : undefined;

  if (Object.keys(errors).length) fail(errors);

  const discount = originalPrice ? Math.round((1 - price / originalPrice) * 100) : undefined;
  return {
    name, category, price,
    ...(originalPrice ? { originalPrice, ...(discount ? { discount } : {}) } : {}),
    image: images[0], images,
    rating: existing?.rating ?? 0,
    reviews: existing?.reviews ?? 0,
    description, sizes,
    ...(Object.keys(sizePrices).length ? { sizePrices } : {}),
    colors,
    ...(badge ? { badge } : {}),
    newArrival: data.newArrival === true,
    bestSeller: data.bestSeller === true,
    available: data.available !== false,
  };
}

// ------------------------------------------------------------------------------------------------------------
export function validateCategory(input, state, existing) {
  const errors = {};
  const data = input && typeof input === 'object' ? input : {};

  const name = oneLine(data.name);
  if (!name) errors.name = 'Enter the category name.';
  else if (name.length < 2 || name.length > 40) errors.name = 'Category name must be 2 to 40 characters.';
  else if (state.categories.some((c) => c.id !== existing?.id && c.name.toLowerCase() === name.toLowerCase())) errors.name = 'You already have a category with this name.';

  const image = data.image;
  if (!image) errors.image = 'Add a category photo.';
  else {
    const bad = imageProblem(image, inlineImagesIn(state));
    if (bad) errors.image = bad;
  }
  if (Object.keys(errors).length) fail(errors);
  return { name, image };
}

export function makeSlug(name, state) {
  const base = oneLine(name).toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40);
  let slug = base || 'category';
  const taken = (s) => RESERVED_SLUGS.has(s) || state.categories.some((c) => c.id === s);
  for (let i = 2; taken(slug); i += 1) slug = `${base || 'category'}-${i}`;
  return slug;
}

// ------------------------------------------------------------------------------------------------------------
export function normalizeWhatsApp(raw) {
  let v = String(raw ?? '').trim().replace(/[\s\-().]/g, '');
  if (v.startsWith('+')) v = v.slice(1);
  else if (v.startsWith('00')) v = v.slice(2);
  return v;
}

export function validateSettings(input) {
  const errors = {};
  const number = normalizeWhatsApp(input?.whatsappNumber);
  if (!number) errors.whatsappNumber = 'Enter the WhatsApp number.';
  else if (!/^\d+$/.test(number)) errors.whatsappNumber = 'Use digits only (you may start with +).';
  else if (number.startsWith('0')) errors.whatsappNumber = 'Start with the country code, not 0. For India: 91 followed by the 10-digit number.';
  else if (number.length < 10 || number.length > 15) errors.whatsappNumber = 'Enter the country code followed by the number (10 to 15 digits in total). Example: 919876543210.';
  if (Object.keys(errors).length) fail(errors);
  return { whatsappNumber: number };
}
