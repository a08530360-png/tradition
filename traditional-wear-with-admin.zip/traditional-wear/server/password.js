// Password hashing with Node's built-in scrypt (no extra libraries).
// Stored format:  scrypt:N:r:p:salt:hash   (salt/hash are base64url)
import crypto from 'node:crypto';

const N = 16384, R = 8, P = 1, KEYLEN = 64;

const scrypt = (password, salt, n, r, p, len) =>
  new Promise((resolve, reject) =>
    crypto.scrypt(password, salt, len, { N: n, r, p, maxmem: 64 * 1024 * 1024 }, (err, key) => (err ? reject(err) : resolve(key))),
  );

export async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const key = await scrypt(password, salt, N, R, P, KEYLEN);
  return ['scrypt', N, R, P, salt.toString('base64url'), key.toString('base64url')].join(':');
}

export async function verifyPassword(password, stored) {
  const parts = String(stored).split(':');
  if (parts.length !== 6 || parts[0] !== 'scrypt') return false;
  const [, n, r, p, saltB64, hashB64] = parts;
  try {
    const expected = Buffer.from(hashB64, 'base64url');
    const actual = await scrypt(password, Buffer.from(saltB64, 'base64url'), Number(n), Number(r), Number(p), expected.length);
    return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
  } catch {
    return false;
  }
}

export const MIN_PASSWORD_LENGTH = 10;
