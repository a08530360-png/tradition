// Admin authentication: login check, signed session cookie, brute-force limiter, CSRF guard.
import crypto from 'node:crypto';
import {
  ADMIN_USERNAME, ADMIN_PASSWORD_HASH, ADMIN_PASSWORD, SESSION_SECRET, SESSION_HOURS, ALLOWED_ORIGINS, TRUST_PROXY,
} from './config.js';
import { hashPassword, verifyPassword, MIN_PASSWORD_LENGTH } from './password.js';
import { HttpError } from './validate.js';

const COOKIE = 'tw_admin';

// ---- Work out whether the admin is configured, and with which credential -------------------------------------
let credential = ADMIN_PASSWORD_HASH;
let problem = '';

export async function initAuth() {
  if (!credential && ADMIN_PASSWORD) {
    if (ADMIN_PASSWORD.length < MIN_PASSWORD_LENGTH) problem = `ADMIN_PASSWORD must be at least ${MIN_PASSWORD_LENGTH} characters.`;
    else {
      credential = await hashPassword(ADMIN_PASSWORD); // kept only in memory
      console.warn('[admin] Using plain ADMIN_PASSWORD. Safer: run "npm run set-password" and use ADMIN_PASSWORD_HASH instead.');
    }
  }
  if (!ADMIN_USERNAME) problem ||= 'ADMIN_USERNAME is not set.';
  if (!credential) problem ||= 'ADMIN_PASSWORD_HASH is not set.';
  if (SESSION_SECRET.length < 32) problem ||= 'SESSION_SECRET is missing or shorter than 32 characters.';
  if (problem) console.warn(`[admin] Admin login is DISABLED: ${problem} Run "npm run setup".`);
}
export const isConfigured = () => !problem;
export const configProblem = () => problem;

// ---- Signed session token (stateless). Changing the password or secret invalidates all sessions -----------------
const signingKey = () =>
  crypto.createHash('sha256').update(`${SESSION_SECRET}|${ADMIN_USERNAME}|${credential}`).digest();
const sign = (data) => crypto.createHmac('sha256', signingKey()).update(data).digest('base64url');

function createToken(username) {
  const payload = Buffer.from(JSON.stringify({ u: username, exp: Date.now() + SESSION_HOURS * 3600_000, n: crypto.randomBytes(8).toString('hex') })).toString('base64url');
  return `${payload}.${sign(payload)}`;
}
function readToken(token) {
  if (!isConfigured() || typeof token !== 'string') return null;
  const [payload, sig] = token.split('.');
  if (!payload || !sig) return null;
  const expected = sign(payload);
  const a = Buffer.from(sig), b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString());
    return data.exp > Date.now() && data.u === ADMIN_USERNAME ? data : null;
  } catch {
    return null;
  }
}

function parseCookies(header = '') {
  const out = {};
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

export const currentSession = (req) => readToken(parseCookies(req.headers.cookie)[COOKIE]);

function setCookie(req, res, value, maxAgeSec) {
  const flags = [`${COOKIE}=${value}`, 'Path=/', 'HttpOnly', 'SameSite=Strict', `Max-Age=${maxAgeSec}`];
  if (req.secure) flags.push('Secure');
  res.append('Set-Cookie', flags.join('; '));
}

// ---- Login (with brute-force protection) --------------------------------------------------------------------
const attempts = new Map(); // ip -> { fails, first, lockedUntil }
const MAX_FAILS = 5, WINDOW_MS = 15 * 60_000;
setInterval(() => {
  const now = Date.now();
  for (const [ip, a] of attempts) if (now - a.first > WINDOW_MS && (a.lockedUntil || 0) < now) attempts.delete(ip);
}, 5 * 60_000).unref();

const safeEqual = (a, b) => {
  const ha = crypto.createHash('sha256').update(String(a)).digest();
  const hb = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(ha, hb);
};

export async function login(req, res) {
  if (!isConfigured()) throw new HttpError(503, 'Admin login is not set up yet. Run "npm run setup" on the server.');
  const ip = req.ip || 'unknown';
  const now = Date.now();
  let rec = attempts.get(ip);
  if (rec && rec.lockedUntil > now) {
    res.set('Retry-After', String(Math.ceil((rec.lockedUntil - now) / 1000)));
    throw new HttpError(429, 'Too many failed attempts. Please wait 15 minutes and try again.');
  }
  if (!rec || now - rec.first > WINDOW_MS) rec = { fails: 0, first: now, lockedUntil: 0 };

  const { username, password } = req.body || {};
  const userOk = safeEqual(username ?? '', ADMIN_USERNAME);
  const passOk = await verifyPassword(typeof password === 'string' ? password.slice(0, 200) : '', credential); // always run
  if (!(userOk && passOk)) {
    rec.fails += 1;
    if (rec.fails >= MAX_FAILS) rec.lockedUntil = now + WINDOW_MS;
    attempts.set(ip, rec);
    await new Promise((r) => setTimeout(r, 400));
    throw new HttpError(401, 'Incorrect username or password.');
  }
  attempts.delete(ip);
  setCookie(req, res, createToken(ADMIN_USERNAME), SESSION_HOURS * 3600);
}

export function logout(req, res) {
  setCookie(req, res, '', 0);
}

// ---- Middleware ----------------------------------------------------------------------------------------------
export function requireAdmin(req, _res, next) {
  const s = currentSession(req);
  if (!s) return next(new HttpError(401, 'Please sign in.'));
  req.admin = s;
  next();
}

// Blocks cross-site requests: a custom header (cannot be sent cross-site without CORS) + Origin check.
export function csrfGuard(req, _res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  if (req.get('x-requested-with') !== 'tw-admin') return next(new HttpError(403, 'Blocked request (missing header).'));
  const origin = req.get('origin');
  if (origin) {
    let host = '';
    try { host = new URL(origin).host; } catch { /* invalid */ }
    const own = (TRUST_PROXY && req.get('x-forwarded-host')?.split(',')[0].trim()) || req.get('host');
    const allowed = [own, ...ALLOWED_ORIGINS.map((o) => { try { return new URL(o).host; } catch { return o; } })];
    if (!allowed.includes(host)) return next(new HttpError(403, 'Blocked request (origin mismatch).'));
  }
  next();
}
