import { useStore } from '../context/StoreContext';
import Ornament from './Ornament';
import Reveal from './Reveal';

const PATTERN =
  "url(\"data:image/svg+xml;utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='48' height='48'%3E%3Cpath d='M24 4l20 20-20 20L4 24z' fill='none' stroke='%23B8965A' stroke-opacity='.18'/%3E%3C/svg%3E\")";

export default function PromoBanner() {
  const { browse } = useStore();
  return (
    <section aria-label="Offer" className="px-4 sm:px-6">
      <Reveal>
        <div
          className="relative mx-auto max-w-7xl overflow-hidden rounded-[2rem] bg-burgundy px-6 py-14 text-center sm:py-20"
          style={{ backgroundImage: PATTERN }}
        >
          <div className="pointer-events-none absolute inset-3 rounded-[1.5rem] border border-gold/50" aria-hidden="true" />
          <div className="relative">
            <Ornament />
            <h2 className="mx-auto mt-5 max-w-3xl font-display text-3xl font-semibold uppercase leading-tight tracking-[0.06em] text-ivory sm:text-5xl">
              A little more style, a little more saving
            </h2>
            <p className="mx-auto mt-4 max-w-md text-base text-ivory/80">
              Discover beautiful ethnic styles at prices you'll love.
            </p>
            <p className="mx-auto mt-6 inline-block rounded-full border border-gold-light/70 px-5 py-2 text-xs font-semibold tracking-[0.2em] text-gold-light">
              UP TO 20% OFF SELECTED STYLES
            </p>
            <div className="mt-8">
              <button
                type="button"
                onClick={() => browse('all')}
                className="inline-flex min-h-[48px] items-center justify-center rounded-full bg-gold-light px-8 text-sm font-semibold tracking-[0.12em] text-burgundy transition hover:bg-ivory active:scale-[0.98]"
              >
                SHOP NOW
              </button>
            </div>
          </div>
        </div>
      </Reveal>
    </section>
  );
}
