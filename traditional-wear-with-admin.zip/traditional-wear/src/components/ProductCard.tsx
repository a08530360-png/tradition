import type { Product } from '../types';
import { useStore } from '../context/StoreContext';
import { formatPrice, priceSpread } from '../utils';
import { Icon } from './Icons';
import Stars from './Stars';

export default function ProductCard({ product, compact = false }: { product: Product; compact?: boolean }) {
  const { addToCart, toggleWish, isWished, openQuickView } = useStore();
  const wished = isWished(product.id);
  const soldOut = product.available === false;
  const { min, max } = priceSpread(product);
  const varies = min !== max; // some sizes cost more

  return (
    <article className="group flex h-full flex-col">
      <div className="relative aspect-[3/4] overflow-hidden rounded-2xl bg-beige">
        <button
          type="button"
          onClick={() => openQuickView(product)}
          aria-label={`View details for ${product.name}`}
          className="block h-full w-full"
        >
          <img
            src={product.image}
            alt={`${product.name} - ${product.category.replace('-', ' ')}`}
            loading="lazy"
            decoding="async"
            width={600}
            height={800}
            className={`h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-105 ${soldOut ? 'opacity-60' : ''}`}
          />
        </button>

        {(soldOut || product.badge) && (
          <span className={`pointer-events-none absolute left-2.5 top-2.5 rounded-full px-2.5 py-1 text-[10px] font-semibold tracking-[0.16em] text-ivory sm:left-3 sm:top-3 ${soldOut ? 'bg-charcoal' : 'bg-maroon'}`}>
            {soldOut ? 'SOLD OUT' : product.badge}
          </span>
        )}

        <button
          type="button"
          onClick={() => toggleWish(product.id)}
          aria-pressed={wished}
          aria-label={wished ? `Remove ${product.name} from wishlist` : `Add ${product.name} to wishlist`}
          className={`absolute right-2 top-2 flex h-11 w-11 items-center justify-center rounded-full bg-ivory/90 backdrop-blur transition hover:scale-105 ${
            wished ? 'text-maroon' : 'text-charcoal/70'
          }`}
        >
          <Icon name="heart" filled={wished} className="h-5 w-5" />
        </button>

        <span className="pointer-events-none absolute inset-x-3 bottom-3 hidden translate-y-2 items-center justify-center gap-2 rounded-full bg-ivory/95 py-2.5 text-[11px] font-semibold tracking-[0.16em] text-burgundy opacity-0 transition duration-300 group-hover:translate-y-0 group-hover:opacity-100 lg:flex">
          <Icon name="eye" className="h-4 w-4" /> QUICK VIEW
        </span>
      </div>

      <div className="flex flex-1 flex-col pt-3.5">
        <h3 className="font-display text-lg font-semibold leading-snug text-burgundy sm:text-xl">{product.name}</h3>
        {!compact && (
          <p className="mt-1 line-clamp-1 text-[13px] text-charcoal/60">{product.description}</p>
        )}
        <div className="mt-2">
          <Stars rating={product.rating} reviews={product.reviews} />
        </div>
        <div className="mt-2 flex flex-wrap items-baseline gap-x-2 gap-y-0.5">
          <span className="text-base font-semibold text-charcoal">{varies && <span className="mr-1 text-xs font-medium text-charcoal/60">From</span>}{formatPrice(min)}</span>
          {!varies && product.originalPrice && (
            <span className="text-sm text-charcoal/45 line-through">{formatPrice(product.originalPrice)}</span>
          )}
          {!varies && product.discount && (
            <span className="text-xs font-semibold text-maroon">{product.discount}% off</span>
          )}
        </div>
        <div className="mt-auto pt-4">
          <button
            type="button"
            onClick={() => addToCart(product)}
            disabled={soldOut}
            aria-label={soldOut ? `${product.name} is sold out` : `Add ${product.name} to cart`}
            className="min-h-[46px] w-full rounded-full border border-maroon text-xs font-semibold tracking-[0.14em] text-maroon transition duration-300 hover:bg-maroon hover:text-ivory active:scale-[0.98] disabled:cursor-not-allowed disabled:border-beige disabled:text-charcoal/40 disabled:hover:bg-transparent disabled:hover:text-charcoal/40 disabled:active:scale-100"
          >
            {soldOut ? 'SOLD OUT' : 'ADD TO CART'}
          </button>
        </div>
      </div>
    </article>
  );
}
