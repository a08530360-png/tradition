import { Icon, type IconName } from './Icons';

const BENEFITS: { icon: IconName; title: string; text: string }[] = [
  { icon: 'truck', title: 'Fast Delivery', text: 'Quick & reliable delivery' },
  { icon: 'sparkle', title: 'Quality Fashion', text: 'Carefully selected styles' },
  { icon: 'card', title: 'Secure Payments', text: 'Safe & convenient checkout' },
  { icon: 'chat', title: 'Customer Support', text: "We're here to help" },
];

export default function BenefitsBar() {
  return (
    <section aria-label="Why shop with us" className="border-y border-beige bg-cream">
      <ul className="mx-auto grid max-w-7xl grid-cols-2 gap-x-4 gap-y-6 px-4 py-8 sm:px-6 lg:grid-cols-4">
        {BENEFITS.map((b) => (
          <li key={b.title} className="flex flex-col items-center gap-3 text-center lg:flex-row lg:justify-center lg:text-left">
            <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full border border-gold/60 text-maroon">
              <Icon name={b.icon} className="h-5 w-5" />
            </span>
            <div>
              <h3 className="font-body text-sm font-semibold text-burgundy">{b.title}</h3>
              <p className="text-xs text-charcoal/65 sm:text-[13px]">{b.text}</p>
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}
