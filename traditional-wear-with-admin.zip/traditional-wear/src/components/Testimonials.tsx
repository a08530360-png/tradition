import { useEffect, useState } from 'react';
import { Icon } from './Icons';
import Reveal from './Reveal';

/* Sample reviews - replace with real customer feedback (with their permission). */
const REVIEWS = [
  { name: 'Priya', text: 'Beautiful outfit and exactly as shown in the pictures. Loved the quality!' },
  { name: 'Ananya', text: 'The dress was even more beautiful in person. Perfect for my occasion.' },
  { name: 'Neha', text: 'Loved the design, fitting and overall shopping experience.' },
];

export default function Testimonials() {
  const [i, setI] = useState(0);
  const [paused, setPaused] = useState(false);
  const go = (n: number) => setI((n + REVIEWS.length) % REVIEWS.length);

  useEffect(() => {
    if (paused || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const t = window.setInterval(() => setI((x) => (x + 1) % REVIEWS.length), 6000);
    return () => window.clearInterval(t);
  }, [paused]);

  const arrow = 'flex h-11 w-11 items-center justify-center rounded-full border border-maroon text-maroon transition hover:bg-maroon hover:text-ivory';

  return (
    <section id="reviews" className="mx-auto max-w-4xl px-4 py-16 sm:px-6 lg:py-24" onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)} onFocus={() => setPaused(true)} onBlur={() => setPaused(false)}>
      <Reveal>
        <h2 className="section-title">What Our Customers Say</h2>
      </Reveal>

      <div className="mt-10 grid text-center" aria-roledescription="carousel" aria-label="Customer reviews">
        {REVIEWS.map((r, n) => (
          <figure
            key={r.name}
            aria-hidden={n !== i}
            className={`[grid-area:1/1] px-2 transition-all duration-700 ${n === i ? 'translate-y-0 opacity-100' : 'pointer-events-none translate-y-3 opacity-0'}`}
          >
            <div className="flex justify-center gap-1 text-gold" aria-label="5 out of 5 stars">
              {[1, 2, 3, 4, 5].map((s) => <Icon key={s} name="star" filled className="h-5 w-5" />)}
            </div>
            <blockquote className="mx-auto mt-5 max-w-2xl font-display text-2xl italic leading-snug text-burgundy sm:text-4xl">
              “{r.text}”
            </blockquote>
            <figcaption className="mt-5 text-sm font-semibold tracking-wide text-charcoal/70">- {r.name}</figcaption>
          </figure>
        ))}
      </div>

      <div className="mt-8 flex items-center justify-center gap-4">
        <button type="button" className={arrow} onClick={() => go(i - 1)} aria-label="Previous review"><Icon name="chevL" /></button>
        <div className="flex gap-2">
          {REVIEWS.map((r, n) => (
            <button key={r.name} type="button" onClick={() => setI(n)} aria-label={`Show review ${n + 1}`} aria-current={n === i} className="flex h-6 w-6 items-center justify-center">
              <span className={`h-2 rounded-full transition-all ${n === i ? 'w-6 bg-maroon' : 'w-2 bg-beige'}`} />
            </button>
          ))}
        </div>
        <button type="button" className={arrow} onClick={() => go(i + 1)} aria-label="Next review"><Icon name="chevR" /></button>
      </div>
    </section>
  );
}
