import { STORE_NAME } from '../config';
import { whatsappHref } from '../utils';
import { Icon } from './Icons';

export default function WhatsAppButton() {
  return (
    <a
      href={whatsappHref(`Hi ${STORE_NAME}! I'd like to know more about your collection.`)}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat with us on WhatsApp"
      className="group fixed bottom-4 right-4 z-40 flex items-center sm:bottom-6 sm:right-6"
    >
      <span className="pointer-events-none mr-3 whitespace-nowrap rounded-full bg-charcoal px-3.5 py-2 text-xs font-medium text-ivory opacity-0 shadow-lg transition group-hover:opacity-100 group-focus-visible:opacity-100">
        Chat With Us
      </span>
      <span className="flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] text-white shadow-lg transition group-hover:scale-105">
        <Icon name="whatsapp" className="h-7 w-7" />
      </span>
    </a>
  );
}
