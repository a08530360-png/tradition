import { useState, type FormEvent } from 'react';
import Reveal from './Reveal';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export default function Newsletter() {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [done, setDone] = useState(false);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!EMAIL_RE.test(email.trim())) {
      setError('Please enter a valid email address, like name@example.com.');
      return;
    }
    setError('');
    // TODO: send `email` to your mailing list (Mailchimp, Brevo, Formspree, etc.)
    setDone(true);
    setEmail('');
  };

  return (
    <section className="px-4 pb-16 sm:px-6 lg:pb-24" aria-labelledby="newsletter-title">
      <Reveal>
        <div className="mx-auto max-w-3xl rounded-[2rem] border border-gold/50 bg-cream px-6 py-12 text-center sm:px-12">
          <h2 id="newsletter-title" className="font-display text-4xl font-semibold uppercase tracking-[0.06em] text-burgundy sm:text-5xl">
            Stay in Style
          </h2>
          <p className="mx-auto mt-3 max-w-md text-[15px] leading-relaxed text-charcoal/70">
            Be the first to discover new arrivals, exclusive offers and festive collections.
          </p>
          {done ? (
            <p role="status" className="mt-8 font-display text-2xl text-maroon">Thank you for joining us ✓</p>
          ) : (
            <form onSubmit={submit} noValidate className="mx-auto mt-8 flex max-w-lg flex-col gap-3 sm:flex-row">
              <div className="flex-1 text-left">
                <label htmlFor="nl-email" className="sr-only">Email address</label>
                <input
                  id="nl-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email address"
                  autoComplete="email"
                  aria-invalid={error !== ''}
                  aria-describedby={error ? 'nl-error' : undefined}
                  className="h-12 w-full rounded-full border border-beige bg-white px-5 text-base outline-none focus:border-gold"
                />
                {error && <p id="nl-error" role="alert" className="mt-2 px-2 text-sm text-maroon">{error}</p>}
              </div>
              <button type="submit" className="btn-primary sm:self-start">JOIN US</button>
            </form>
          )}
        </div>
      </Reveal>
    </section>
  );
}
