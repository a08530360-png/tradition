import { Icon } from './Icons';

export default function Stars({ rating, reviews }: { rating: number; reviews?: number }) {
  if (reviews === 0) return null; // new products have no reviews yet
  return (
    <div className="flex items-center gap-1.5" role="img" aria-label={`Rated ${rating} out of 5`}>
      <div className="flex text-gold">
        {[1, 2, 3, 4, 5].map((n) => (
          <Icon key={n} name="star" filled={n <= Math.round(rating)} className="h-3.5 w-3.5" />
        ))}
      </div>
      <span className="text-xs text-charcoal/60">
        {rating.toFixed(1)}
        {reviews !== undefined && ` (${reviews})`}
      </span>
    </div>
  );
}
