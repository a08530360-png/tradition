import { useState } from 'react';
import type { Product } from '../types';
import { useStore } from '../context/StoreContext';
import { useOverlay } from '../hooks';
import { formatPrice, unitPrice } from '../utils';
import { Icon } from './Icons';
import Stars from './Stars';

function Details({ product, onClose }: { product: Product; onClose: () => void }) {
  const { addToCart, toggleWish, isWished, openDrawer } = useStore();
  const [size, setSize] = useState(product.sizes[0]);
  const [color, setColor] = useState(product.colors[0]?.name ?? '');
  const [qty, setQty] = useState(1);
  const wished = isWished(product.id);
  const soldOut = product.available === false;
  const images = product.images?.length ? product.images : [product.image];
  const [imgIdx, setImgIdx] = useState(0);
  const price = unitPrice(product, size);
  const showSale = price === product.price; // sale price/discount belong to the standard price

  return (
    <div className="anim-pop relative grid max-h-[92svh] w-full max-w-4xl overflow-y-auto rounded-3xl bg-ivory shadow-soft md:grid-cols-2">
      <button
        type="button"
        onClick={onClose}
        aria-label="Close product details"
        className="absolute right-3 top-3 z-10 flex h-11 w-11 items-center justify-center rounded-full bg-ivory/90 text-burgundy"
      >
        <Icon name="close" />
      </button>

      <div className="relative aspect-[3/4] bg-beige md:aspect-auto md:min-h-[30rem]">
        <img src={images[imgIdx] ?? product.image} alt={product.name} width={600} height={800} className={`absolute inset-0 h-full w-full object-cover ${soldOut ? 'opacity-70' : ''}`} />
        {(soldOut || product.badge) && (
          <span className={`absolute left-3 top-3 rounded-full px-3 py-1 text-[10px] font-semibold tracking-[0.16em] text-ivory ${soldOut ? 'bg-charcoal' : 'bg-maroon'}`}>
            {soldOut ? 'SOLD OUT' : product.badge}
          </span>
        )}
        {images.length > 1 && (
          <div className="absolute inset-x-3 bottom-3 flex justify-center gap-2" role="group" aria-label="Product photos">
            {images.map((src, i) => (
              <button
                key={src}
                type="button"
                onClick={() => setImgIdx(i)}
                aria-label={`Show photo ${i + 1}`}
                aria-pressed={imgIdx === i}
                className={`h-14 w-11 overflow-hidden rounded-lg border-2 bg-beige transition ${imgIdx === i ? 'border-gold' : 'border-ivory/80 opacity-80'}`}
              >
                <img src={src} alt="" className="h-full w-full object-cover" />
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="flex flex-col p-5 sm:p-8">
        <h2 id="product-modal-title" className="pr-10 font-display text-3xl font-semibold text-burgundy">{product.name}</h2>
        <div className="mt-2"><Stars rating={product.rating} reviews={product.reviews} /></div>
        <div className="mt-3 flex items-baseline gap-2.5">
          <span className="text-xl font-semibold">{formatPrice(price)}</span>
          {showSale && product.originalPrice && <span className="text-charcoal/45 line-through">{formatPrice(product.originalPrice)}</span>}
          {showSale && product.discount && <span className="text-sm font-semibold text-maroon">{product.discount}% off</span>}
        </div>
        <p className="mt-4 text-[15px] leading-relaxed text-charcoal/75">{product.description}</p>

        <fieldset className="mt-6">
          <legend className="text-sm font-semibold text-burgundy">Colour: <span className="font-normal text-charcoal/70">{color}</span></legend>
          <div className="mt-2 flex gap-2.5">
            {product.colors.map((c) => (
              <button
                key={c.name}
                type="button"
                onClick={() => setColor(c.name)}
                aria-label={c.name}
                aria-pressed={color === c.name}
                className={`h-10 w-10 rounded-full border-2 transition ${color === c.name ? 'border-gold ring-2 ring-gold/30' : 'border-beige'}`}
                style={{ backgroundColor: c.hex }}
              />
            ))}
          </div>
        </fieldset>

        <fieldset className="mt-5">
          <legend className="text-sm font-semibold text-burgundy">Size</legend>
          <div className="mt-2 flex flex-wrap gap-2">
            {product.sizes.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setSize(s)}
                aria-pressed={size === s}
                className={`h-11 min-w-[46px] rounded-full border px-3 text-sm transition ${
                  size === s ? 'border-maroon bg-maroon text-ivory' : 'border-beige hover:border-gold'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </fieldset>

        <div className="mt-6 flex items-center gap-3">
          <div className="flex items-center rounded-full border border-beige">
            <button type="button" className="flex h-11 w-11 items-center justify-center" onClick={() => setQty((q) => Math.max(1, q - 1))} aria-label="Decrease quantity"><Icon name="minus" className="h-4 w-4" /></button>
            <span className="w-8 text-center text-sm font-semibold" aria-live="polite">{qty}</span>
            <button type="button" className="flex h-11 w-11 items-center justify-center" onClick={() => setQty((q) => Math.min(10, q + 1))} aria-label="Increase quantity"><Icon name="plus" className="h-4 w-4" /></button>
          </div>
          <button
            type="button"
            onClick={() => toggleWish(product.id)}
            aria-pressed={wished}
            aria-label={wished ? 'Remove from wishlist' : 'Add to wishlist'}
            className={`flex h-12 w-12 items-center justify-center rounded-full border border-beige ${wished ? 'text-maroon' : 'text-charcoal/70'}`}
          >
            <Icon name="heart" filled={wished} />
          </button>
        </div>

        <div className="mt-5 flex flex-col gap-3 sm:flex-row">
          <button type="button" disabled={soldOut} className="btn-primary flex-1 disabled:cursor-not-allowed disabled:bg-beige disabled:text-charcoal/50 disabled:shadow-none" onClick={() => addToCart(product, { size, color, qty })}>
            {soldOut ? 'SOLD OUT' : 'ADD TO CART'}
          </button>
          {!soldOut && (
            <button
              type="button"
              className="btn-outline flex-1"
              onClick={() => { addToCart(product, { size, color, qty }); onClose(); openDrawer('bag'); }}
            >
              BUY NOW
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

export default function ProductModal() {
  const { quickView, closeQuickView } = useStore();
  useOverlay(quickView !== null, closeQuickView);
  if (!quickView) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6" role="dialog" aria-modal="true" aria-labelledby="product-modal-title">
      <div className="anim-fade absolute inset-0 bg-burgundy/55" onClick={closeQuickView} />
      <Details key={quickView.id} product={quickView} onClose={closeQuickView} />
    </div>
  );
}
