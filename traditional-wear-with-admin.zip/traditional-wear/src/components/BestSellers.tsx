import { useRef } from 'react';
import { PRODUCTS } from '../data/catalog';
import { useStore } from '../context/StoreContext';
import { Icon } from './Icons';
import ProductCard from './ProductCard';
import Reveal from './Reveal';

export default function BestSellers() {
  const { browse } = useStore();
  const track = useRef<HTMLDivElement>(null);
  const items = PRODUCTS.filter((p) => p.bestSeller).slice(0, 6);

  const scroll = (dir: 1 | -1) => {
    const el = track.current;
    if (el) el.scrollBy({ left: dir * el.clientWidth * 0.8, behavior: 'smooth' });
  };
  const arrow =
    'hidden h-12 w-12 items-center justify-center rounded-full border border-maroon text-maroon transition hover:bg-maroon hover:text-ivory md:flex';

  return (
    <section id="best-sellers" className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-24">
      <Reveal>
        <h2 className="section-title">Customer Favourites</h2>
        <p className="section-sub">Loved styles that deserve a place in your wardrobe.</p>
      </Reveal>

      <div className="mt-10 flex items-center gap-4">
        <button type="button" className={arrow} onClick={() => scroll(-1)} aria-label="Scroll favourites left"><Icon name="chevL" /></button>
        <div
          ref={track}
          className="no-scrollbar -mx-4 flex flex-1 snap-x snap-mandatory gap-4 overflow-x-auto px-4 pb-2 sm:mx-0 sm:px-0"
          tabIndex={0}
          aria-label="Customer favourites carousel"
        >
          {items.map((p) => (
            <div key={p.id} className="w-[64%] shrink-0 snap-start sm:w-[38%] md:w-[31%] lg:w-[23.5%]">
              <ProductCard product={p} compact />
            </div>
          ))}
        </div>
        <button type="button" className={arrow} onClick={() => scroll(1)} aria-label="Scroll favourites right"><Icon name="chevR" /></button>
      </div>

      <div className="mt-10 text-center">
        <button type="button" className="btn-outline" onClick={() => browse('all')}>VIEW ALL PRODUCTS</button>
      </div>
    </section>
  );
}
