import type { MouseEvent } from 'react';
import { EMAIL, INSTAGRAM, STORE_NAME } from '../config';
import { useStore } from '../context/StoreContext';
import { emailHref, facebookHref, instagramHref, whatsappHref } from '../utils';
import { Icon, type IconName } from './Icons';

const linkCls = 'inline-flex min-h-[32px] items-center text-sm text-ivory/75 transition hover:text-gold-light';

export default function Footer() {
  const { browse, showToast } = useStore();
  const soon = (e: MouseEvent) => {
    e.preventDefault();
    showToast('This page is coming soon');
  };

  const social: { icon: IconName; label: string; href: string }[] = [
    { icon: 'instagram', label: 'Instagram', href: instagramHref() },
    { icon: 'facebook', label: 'Facebook', href: facebookHref() },
    { icon: 'whatsapp', label: 'WhatsApp', href: whatsappHref() },
    { icon: 'mail', label: 'Email', href: emailHref() },
  ];

  return (
    <footer id="contact" className="bg-burgundy text-ivory">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
        <div>
          <p className="font-display text-3xl font-semibold text-gold-light">{STORE_NAME}</p>
          <p className="mt-3 max-w-xs text-sm leading-relaxed text-ivory/75">Timeless Indian fashion for the modern woman.</p>
          <div className="mt-5 flex gap-2">
            {social.map((s) => (
              <a key={s.label} href={s.href} target="_blank" rel="noopener noreferrer" aria-label={s.label} className="flex h-11 w-11 items-center justify-center rounded-full border border-gold/50 text-gold-light transition hover:bg-gold-light hover:text-burgundy">
                <Icon name={s.icon} />
              </a>
            ))}
          </div>
        </div>

        <nav aria-label="Shop">
          <h3 className="font-body text-xs font-semibold tracking-[0.2em] text-gold-light">SHOP</h3>
          <ul className="mt-4 space-y-1">
            <li><button type="button" className={linkCls} onClick={() => browse('new-arrivals')}>New Arrivals</button></li>
            <li><button type="button" className={linkCls} onClick={() => browse('ethnic-dresses')}>Dresses</button></li>
            <li><button type="button" className={linkCls} onClick={() => browse('traditional-wear')}>Ethnic Wear</button></li>
            <li><button type="button" className={linkCls} onClick={() => browse('festive')}>Festive Collection</button></li>
            <li><button type="button" className={linkCls} onClick={() => document.getElementById('best-sellers')?.scrollIntoView({ behavior: 'smooth' })}>Best Sellers</button></li>
          </ul>
        </nav>

        <nav aria-label="Information">
          <h3 className="font-body text-xs font-semibold tracking-[0.2em] text-gold-light">INFORMATION</h3>
          <ul className="mt-4 space-y-1">
            <li><button type="button" className={linkCls} onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}>About Us</button></li>
            <li><a className={linkCls} href={whatsappHref()} target="_blank" rel="noopener noreferrer">Contact Us</a></li>
            {['Shipping Policy', 'Return Policy', 'Privacy Policy', 'Terms & Conditions'].map((t) => (
              <li key={t}><a className={linkCls} href="#" onClick={soon}>{t}</a></li>
            ))}
          </ul>
        </nav>

        <nav aria-label="Customer care">
          <h3 className="font-body text-xs font-semibold tracking-[0.2em] text-gold-light">CUSTOMER CARE</h3>
          <ul className="mt-4 space-y-1">
            <li><a className={linkCls} href={whatsappHref()} target="_blank" rel="noopener noreferrer">WhatsApp</a></li>
            <li><a className={linkCls} href={instagramHref()} target="_blank" rel="noopener noreferrer">Instagram</a></li>
            <li><a className={linkCls} href={facebookHref()} target="_blank" rel="noopener noreferrer">Facebook</a></li>
            <li><a className={linkCls} href={emailHref()}>Email</a></li>
          </ul>
          <p className="mt-3 text-xs text-ivory/50">{INSTAGRAM}{EMAIL.startsWith('REPLACE') ? '' : ` · ${EMAIL}`}</p>
        </nav>
      </div>
      <div className="border-t border-gold/25 px-4 py-5 text-center text-xs text-ivory/60">
        © 2026 {STORE_NAME}. All Rights Reserved.
      </div>
    </footer>
  );
}
