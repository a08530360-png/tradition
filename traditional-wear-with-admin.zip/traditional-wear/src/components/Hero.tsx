import type { CSSProperties } from 'react';
import { IMAGES } from '../data/images';
import { useStore } from '../context/StoreContext';
import { scrollToId } from '../utils';

export default function Hero() {
  const { browse } = useStore();
  const rise = (ms: number) => ({ '--d': `${ms}ms` } as CSSProperties);

  return (
    <section id="home" className="relative overflow-hidden bg-gradient-to-b from-ivory to-cream">
      <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 pb-14 pt-8 sm:px-6 lg:grid-cols-[1.05fr_1fr] lg:gap-14 lg:pb-24 lg:pt-14">
        <div className="text-center lg:text-left">
          <span
            className="hero-rise inline-block rounded-full border border-gold/70 px-4 py-1.5 text-[11px] font-semibold tracking-[0.22em] text-maroon"
            style={rise(0)}
          >
            NEW COLLECTION 2026
          </span>
          <h1
            className="hero-rise mt-6 font-display text-[2.6rem] font-semibold uppercase leading-[1.05] tracking-[0.03em] text-burgundy sm:text-6xl lg:text-7xl"
            style={rise(120)}
          >
            Traditional Elegance, Redefined
          </h1>
          <p
            className="hero-rise mx-auto mt-6 max-w-md text-base leading-relaxed text-charcoal/75 sm:text-lg lg:mx-0"
            style={rise(260)}
          >
            Discover timeless Indian fashion, thoughtfully curated for the modern woman.
          </p>
          <div
            className="hero-rise mt-9 flex flex-col gap-3 sm:flex-row sm:justify-center lg:justify-start"
            style={rise(400)}
          >
            <button type="button" className="btn-primary" onClick={() => browse('all')}>
              SHOP COLLECTION
            </button>
            <button type="button" className="btn-outline" onClick={() => scrollToId('new-arrivals')}>
              EXPLORE NEW ARRIVALS
            </button>
          </div>
        </div>

        <div className="hero-rise relative mx-auto w-full max-w-sm sm:max-w-md lg:max-w-none" style={rise(200)}>
          <div className="pointer-events-none absolute -inset-3 translate-x-3 translate-y-3 rounded-t-[999px] rounded-b-[2rem] border border-gold/70" aria-hidden="true" />
          <div className="relative aspect-[4/5] overflow-hidden rounded-t-[999px] rounded-b-[2rem] bg-beige shadow-soft">
            <img
              src={IMAGES.hero}
              alt="Woman wearing an elegant maroon anarkali with gold trim"
              width={800}
              height={1000}
              className="h-full w-full object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
