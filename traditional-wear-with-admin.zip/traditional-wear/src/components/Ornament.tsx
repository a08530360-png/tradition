/** A small gold divider inspired by traditional jaali work. Kept deliberately minimal. */
export default function Ornament({ className = '' }: { className?: string }) {
  return (
    <div className={`flex items-center justify-center gap-3 text-gold ${className}`} aria-hidden="true">
      <span className="h-px w-12 bg-gold/60" />
      <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.2">
        <path d="M12 2l3 7 7 3-7 3-3 7-3-7-7-3 7-3z" />
        <circle cx="12" cy="12" r="1.5" fill="currentColor" />
      </svg>
      <span className="h-px w-12 bg-gold/60" />
    </div>
  );
}
