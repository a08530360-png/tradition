import { CATEGORIES } from '../data/catalog';
import { useStore } from '../context/StoreContext';
import Reveal from './Reveal';

export default function CategorySection() {
  const { browse } = useStore();
  return (
    <section id="categories" className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-24">
      <Reveal>
        <h2 className="section-title">Shop by Category</h2>
        <p className="section-sub">Find your perfect look for every occasion.</p>
      </Reveal>
      <div className="mt-10 grid grid-cols-2 gap-3 sm:gap-5 lg:grid-cols-3">
        {CATEGORIES.map((c, i) => (
          <Reveal key={c.id} delay={(i % 3) * 80}>
            <button
              type="button"
              onClick={() => browse(c.id)}
              aria-label={`Shop ${c.name}`}
              className="group relative block aspect-[4/5] w-full overflow-hidden rounded-2xl bg-beige text-left lg:aspect-[5/6]"
            >
              <img
                src={c.image}
                alt={`${c.name} for women`}
                loading="lazy"
                decoding="async"
                width={600}
                height={800}
                className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
              />
              <span className="absolute inset-0 bg-gradient-to-t from-burgundy/80 via-burgundy/10 to-transparent transition-colors duration-500 group-hover:from-burgundy/90" />
              <span className="absolute inset-x-0 bottom-0 p-4 sm:p-6">
                <span className="block font-display text-xl font-semibold text-ivory sm:text-3xl">{c.name}</span>
                <span className="mt-1 inline-block border-b border-gold-light pb-0.5 text-[11px] font-semibold tracking-[0.2em] text-gold-light transition-all duration-300 group-hover:tracking-[0.28em]">
                  SHOP NOW
                </span>
              </span>
            </button>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
