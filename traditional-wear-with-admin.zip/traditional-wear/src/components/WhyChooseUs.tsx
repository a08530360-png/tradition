import { Icon, type IconName } from './Icons';
import Reveal from './Reveal';

const POINTS: { icon: IconName; title: string; text: string }[] = [
  { icon: 'gem', title: 'Curated With Care', text: 'Every style is selected with attention to design, quality and elegance.' },
  { icon: 'calendar', title: 'Fashion For Every Occasion', text: 'From everyday outfits to festive celebrations and special moments.' },
  { icon: 'layers', title: 'Style Meets Tradition', text: 'Classic Indian aesthetics combined with contemporary fashion.' },
  { icon: 'user', title: 'Made For You', text: 'Beautiful styles designed to help you feel confident and comfortable.' },
];

export default function WhyChooseUs() {
  return (
    <section id="about" className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-24">
      <Reveal>
        <h2 className="section-title">Why Choose Traditional Wear?</h2>
      </Reveal>
      <div className="mt-12 grid gap-x-8 gap-y-10 sm:grid-cols-2 lg:grid-cols-4">
        {POINTS.map((p, i) => (
          <Reveal key={p.title} delay={i * 80}>
            <div className="group text-center">
              <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-gold/60 bg-cream text-maroon transition duration-500 group-hover:-translate-y-1 group-hover:bg-maroon group-hover:text-ivory">
                <Icon name={p.icon} className="h-7 w-7" />
              </span>
              <h3 className="mt-5 text-2xl font-semibold text-burgundy">{p.title}</h3>
              <p className="mx-auto mt-2 max-w-[16rem] text-[15px] leading-relaxed text-charcoal/70">{p.text}</p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
