import { useState } from 'react';
import { Icon } from './Icons';
import Reveal from './Reveal';

/* Edit these answers so they match your real policies before you launch. */
const FAQS = [
  { q: 'How can I place an order?', a: 'Choose your style, pick a size and colour, and add it to your bag. When you are ready, tap "Order on WhatsApp" and we will confirm your order and payment details with you.' },
  { q: 'Do you offer Cash on Delivery?', a: 'Cash on Delivery availability depends on your location. Message us on WhatsApp with your pincode and we will confirm before you order.' },
  { q: 'How long does delivery take?', a: 'Delivery time depends on where you live. We confirm the expected date when your order is placed and share updates once it ships.' },
  { q: 'Do you offer returns or exchanges?', a: 'If something is not right, message us on WhatsApp soon after your order arrives and we will help with a return or exchange. See our Return Policy for full details.' },
  { q: 'How can I track my order?', a: 'Once your order ships, we send tracking details on WhatsApp. You can message us any time for an update.' },
  { q: 'How can I contact customer support?', a: 'Tap the WhatsApp button on this page, message us on Instagram, or email us. We are happy to help with sizing, styling and orders.' },
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section id="faq" className="mx-auto max-w-3xl px-4 pb-16 sm:px-6 lg:pb-24">
      <Reveal>
        <h2 className="section-title">Frequently Asked Questions</h2>
      </Reveal>
      <div className="mt-10 divide-y divide-beige border-y border-beige">
        {FAQS.map((f, n) => {
          const isOpen = open === n;
          return (
            <div key={f.q}>
              <h3>
                <button
                  type="button"
                  id={`faq-btn-${n}`}
                  aria-expanded={isOpen}
                  aria-controls={`faq-panel-${n}`}
                  onClick={() => setOpen(isOpen ? null : n)}
                  className="flex min-h-[60px] w-full items-center justify-between gap-4 py-4 text-left font-display text-xl font-semibold text-burgundy sm:text-2xl"
                >
                  {f.q}
                  <Icon name="chevD" className={`h-5 w-5 shrink-0 text-gold transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} />
                </button>
              </h3>
              <div
                id={`faq-panel-${n}`}
                role="region"
                aria-labelledby={`faq-btn-${n}`}
                className={`grid transition-[grid-template-rows] duration-300 ease-out ${isOpen ? 'grid-rows-[1fr]' : 'grid-rows-[0fr]'}`}
              >
                <div className="overflow-hidden">
                  <p className="pb-5 pr-8 text-[15px] leading-relaxed text-charcoal/70">{f.a}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
