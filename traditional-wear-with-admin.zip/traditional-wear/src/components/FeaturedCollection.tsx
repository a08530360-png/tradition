import { IMAGES } from '../data/images';
import { useStore } from '../context/StoreContext';
import Ornament from './Ornament';
import Reveal from './Reveal';

export default function FeaturedCollection() {
  const { browse } = useStore();
  return (
    <section id="festive-edit" className="overflow-hidden bg-cream py-16 lg:py-24">
      <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 sm:px-6 lg:grid-cols-2 lg:gap-20">
        <Reveal className="order-2 text-center lg:order-1 lg:text-left">
          <Ornament className="lg:justify-start" />
          <h2 className="mt-5 font-display text-4xl font-semibold uppercase leading-tight tracking-[0.06em] text-burgundy sm:text-5xl lg:text-6xl">
            The Festive Edit
          </h2>
          <p className="mx-auto mt-5 max-w-md text-base leading-relaxed text-charcoal/75 sm:text-lg lg:mx-0">
            Celebrate every moment in silhouettes that blend timeless tradition with contemporary elegance.
          </p>
          <button type="button" className="btn-primary mt-8" onClick={() => browse('festive')}>
            SHOP FESTIVE COLLECTION
          </button>
        </Reveal>

        <Reveal className="order-1 lg:order-2">
          <div className="relative mx-auto max-w-md lg:max-w-none">
            <div className="pointer-events-none absolute -left-3 -top-3 h-full w-full rounded-[2rem] border border-gold/70" aria-hidden="true" />
            <div className="relative aspect-[4/5] overflow-hidden rounded-[2rem] bg-beige shadow-soft">
              <img
                src={IMAGES.festive}
                alt="Woman in a maroon and gold festive lehenga"
                loading="lazy"
                decoding="async"
                width={800}
                height={1000}
                className="h-full w-full object-cover transition-transform duration-[1200ms] ease-out hover:scale-105"
              />
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
