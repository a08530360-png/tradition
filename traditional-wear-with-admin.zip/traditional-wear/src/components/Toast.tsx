import { useStore } from '../context/StoreContext';

export default function Toast() {
  const { toast } = useStore();
  return (
    <div className="pointer-events-none fixed inset-x-0 top-20 z-[60] flex justify-center px-4" role="status" aria-live="polite">
      {toast && (
        <div key={toast.id} className="anim-pop rounded-full bg-burgundy px-6 py-3 text-sm font-medium text-ivory shadow-soft">
          {toast.message}
        </div>
      )}
    </div>
  );
}
