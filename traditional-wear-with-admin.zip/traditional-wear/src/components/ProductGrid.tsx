import type { Product } from '../types';
import ProductCard from './ProductCard';
import Reveal from './Reveal';

/** Responsive grid: 1 column on very small phones, 2 on phones/tablets, 4 on desktop. */
export default function ProductGrid({ products }: { products: Product[] }) {
  return (
    <div className="grid grid-cols-1 gap-x-3 gap-y-9 min-[400px]:grid-cols-2 sm:gap-x-5 lg:grid-cols-4">
      {products.map((p, i) => (
        <Reveal key={p.id} delay={(i % 4) * 70} className="h-full">
          <ProductCard product={p} />
        </Reveal>
      ))}
    </div>
  );
}
