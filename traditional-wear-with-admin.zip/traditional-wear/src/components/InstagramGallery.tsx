import { IMAGES } from '../data/images';
import { INSTAGRAM } from '../config';
import { instagramHref } from '../utils';
import { Icon } from './Icons';
import Reveal from './Reveal';

export default function InstagramGallery() {
  return (
    <section id="instagram" className="bg-cream py-16 lg:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <Reveal>
          <h2 className="section-title">Follow Our Style</h2>
          <p className="section-sub">See what's new, get inspired and join our fashion community.</p>
          <p className="mt-4 text-center font-display text-2xl font-semibold text-maroon">{INSTAGRAM}</p>
        </Reveal>

        <ul className="mt-9 grid grid-cols-2 gap-2 sm:grid-cols-3 sm:gap-3 lg:grid-cols-6">
          {IMAGES.instagram.map((src, i) => (
            <li key={i}>
              <a
                href={instagramHref()}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={`View post ${i + 1} on Instagram`}
                className="group relative block aspect-square overflow-hidden rounded-xl bg-beige"
              >
                <img src={src} alt={`Traditional Wear style inspiration ${i + 1}`} loading="lazy" decoding="async" width={400} height={400} className="h-full w-full object-cover object-top transition-transform duration-700 group-hover:scale-105" />
                <span className="absolute inset-0 flex items-center justify-center bg-burgundy/0 text-ivory opacity-0 transition duration-300 group-hover:bg-burgundy/45 group-hover:opacity-100 group-focus-visible:bg-burgundy/45 group-focus-visible:opacity-100">
                  <Icon name="instagram" className="h-7 w-7" />
                </span>
              </a>
            </li>
          ))}
        </ul>

        <div className="mt-9 text-center">
          <a href={instagramHref()} target="_blank" rel="noopener noreferrer" className="btn-primary gap-2">
            <Icon name="instagram" className="h-5 w-5" /> FOLLOW US ON INSTAGRAM
          </a>
        </div>
      </div>
    </section>
  );
}
