import { useEffect, useState, type FormEvent } from 'react';
import { STORE_NAME } from '../config';
import { useStore } from '../context/StoreContext';
import { useOverlay } from '../hooks';
import { scrollToId } from '../utils';
import type { CategoryFilter } from '../types';
import { Icon } from './Icons';

interface NavItem { label: string; target?: string; category?: CategoryFilter }

const NAV: NavItem[] = [
  { label: 'Home', target: 'home' },
  { label: 'New Arrivals', target: 'new-arrivals' },
  { label: 'Dresses', category: 'ethnic-dresses' },
  { label: 'Ethnic Wear', category: 'traditional-wear' },
  { label: 'Best Sellers', target: 'best-sellers' },
  { label: 'About Us', target: 'about' },
  { label: 'Contact', target: 'contact' },
];

function Count({ n }: { n: number }) {
  if (n === 0) return null;
  return (
    <span className="absolute -right-0.5 -top-0.5 flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-maroon px-1 text-[10px] font-semibold text-ivory">
      {n}
    </span>
  );
}

export default function Navbar() {
  const { cartCount, wishlist, openDrawer, browse, searchShop } = useStore();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [q, setQ] = useState('');

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const closeMenu = () => setMenuOpen(false);
  useOverlay(menuOpen, closeMenu);

  const go = (item: NavItem) => {
    setMenuOpen(false);
    setSearchOpen(false);
    if (item.category) browse(item.category);
    else if (item.target) scrollToId(item.target);
  };

  const submitSearch = (e: FormEvent) => {
    e.preventDefault();
    setMenuOpen(false);
    setSearchOpen(false);
    searchShop(q.trim());
  };

  const iconBtn =
    'relative flex h-11 w-11 items-center justify-center rounded-full text-burgundy transition hover:bg-cream';

  return (
    <header
      className={`sticky top-0 z-40 border-b transition-all duration-300 ${
        scrolled ? 'border-beige bg-ivory/95 shadow-soft backdrop-blur' : 'border-transparent bg-ivory'
      }`}
    >
      <div
        className={`mx-auto flex max-w-7xl items-center px-3 transition-all duration-300 sm:px-6 ${
          scrolled ? 'h-14 lg:h-16' : 'h-16 lg:h-20'
        }`}
      >
        <button
          type="button"
          className={`${iconBtn} order-1 -ml-1 lg:hidden`}
          onClick={() => setMenuOpen(true)}
          aria-label="Open menu"
        >
          <Icon name="menu" className="h-6 w-6" />
        </button>
        <div className="order-1 flex-1 lg:hidden" />

        <a
          href="#home"
          onClick={(e) => { e.preventDefault(); scrollToId('home'); }}
          className={`order-2 font-display font-semibold tracking-wide text-maroon transition-all duration-300 lg:order-1 ${
            scrolled ? 'text-xl lg:text-2xl' : 'text-2xl lg:text-3xl'
          }`}
        >
          {STORE_NAME}
        </a>

        <nav aria-label="Main" className="order-2 hidden flex-1 justify-center gap-7 lg:flex">
          {NAV.map((item) => (
            <button
              key={item.label}
              type="button"
              onClick={() => go(item)}
              className="group relative py-2 text-sm font-medium tracking-wide text-charcoal/80 transition hover:text-maroon"
            >
              {item.label}
              <span className="absolute inset-x-0 -bottom-0.5 h-px origin-left scale-x-0 bg-gold transition-transform duration-300 group-hover:scale-x-100" />
            </button>
          ))}
        </nav>

        <div className="order-3 flex flex-1 items-center justify-end gap-0.5 lg:flex-none">
          <button type="button" className={`${iconBtn} hidden lg:flex`} onClick={() => setSearchOpen((s) => !s)} aria-label="Search products" aria-expanded={searchOpen}>
            <Icon name="search" />
          </button>
          <button type="button" className={`${iconBtn} hidden lg:flex`} onClick={() => openDrawer('wishlist')} aria-label={`Wishlist, ${wishlist.length} saved`}>
            <Icon name="heart" />
            <Count n={wishlist.length} />
          </button>
          <button type="button" className={iconBtn} onClick={() => openDrawer('bag')} aria-label={`Shopping bag, ${cartCount} items`}>
            <Icon name="bag" />
            <Count n={cartCount} />
          </button>
        </div>
      </div>

      {searchOpen && (
        <div className="anim-fade hidden border-t border-beige bg-ivory lg:block">
          <form onSubmit={submitSearch} className="mx-auto flex max-w-2xl items-center gap-3 px-6 py-4" role="search">
            <input
              autoFocus
              value={q}
              onChange={(e) => setQ(e.target.value)}
              type="search"
              placeholder="Search anarkali, kurta set, lehenga…"
              aria-label="Search products"
              className="h-12 flex-1 rounded-full border border-beige bg-white px-5 text-sm outline-none focus:border-gold"
            />
            <button type="submit" className="btn-primary">SEARCH</button>
          </form>
        </div>
      )}

      {menuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true" aria-label="Menu">
          <div className="anim-fade absolute inset-0 bg-burgundy/50" onClick={closeMenu} />
          <div className="anim-slide-in-left absolute inset-y-0 left-0 flex w-[86%] max-w-sm flex-col bg-ivory p-5 shadow-soft">
            <div className="flex items-center justify-between">
              <span className="font-display text-2xl font-semibold text-maroon">{STORE_NAME}</span>
              <button type="button" className={iconBtn} onClick={closeMenu} aria-label="Close menu">
                <Icon name="close" />
              </button>
            </div>
            <form onSubmit={submitSearch} className="mt-5 flex gap-2" role="search">
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                type="search"
                placeholder="Search products"
                aria-label="Search products"
                className="h-12 min-w-0 flex-1 rounded-full border border-beige bg-white px-5 text-base outline-none focus:border-gold"
              />
              <button type="submit" className="flex h-12 w-12 items-center justify-center rounded-full bg-maroon text-ivory" aria-label="Search">
                <Icon name="search" />
              </button>
            </form>
            <nav aria-label="Mobile" className="mt-4 flex flex-col">
              {NAV.map((item) => (
                <button
                  key={item.label}
                  type="button"
                  onClick={() => go(item)}
                  className="flex min-h-[52px] items-center border-b border-beige/70 text-left font-display text-2xl text-burgundy"
                >
                  {item.label}
                </button>
              ))}
              <button
                type="button"
                onClick={() => { closeMenu(); openDrawer('wishlist'); }}
                className="flex min-h-[52px] items-center gap-3 text-left text-base font-medium text-charcoal"
              >
                <Icon name="heart" /> Wishlist ({wishlist.length})
              </button>
            </nav>
          </div>
        </div>
      )}
    </header>
  );
}
