import { PRODUCTS } from '../data/catalog';
import ProductGrid from './ProductGrid';
import Reveal from './Reveal';

export default function NewArrivals() {
  const items = PRODUCTS.filter((p) => p.newArrival).slice(0, 4);
  return (
    <section id="new-arrivals" className="mx-auto max-w-7xl px-4 pb-16 sm:px-6 lg:pb-24">
      <Reveal>
        <h2 className="section-title">New Arrivals</h2>
        <p className="section-sub">Fresh styles, timeless elegance.</p>
      </Reveal>
      <div className="mt-10">
        <ProductGrid products={items} />
      </div>
    </section>
  );
}
