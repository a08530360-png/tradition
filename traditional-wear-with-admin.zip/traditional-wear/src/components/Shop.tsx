import { useMemo } from 'react';
import { PRODUCTS, CATEGORIES } from '../data/catalog';
import { PRICE_RANGES } from '../data/categories';
import { useStore } from '../context/StoreContext';
import type { CategoryFilter, SortKey } from '../types';
import { Icon } from './Icons';
import ProductGrid from './ProductGrid';
import Reveal from './Reveal';

const SORTS: { id: SortKey; label: string }[] = [
  { id: 'featured', label: 'Featured' },
  { id: 'newest', label: 'Newest first' },
  { id: 'price-asc', label: 'Price: low to high' },
  { id: 'price-desc', label: 'Price: high to low' },
  { id: 'rating', label: 'Top rated' },
];

const selectCls =
  'h-11 rounded-full border border-beige bg-white px-4 text-sm text-charcoal outline-none focus:border-gold';

export default function Shop() {
  const { filters, setFilters, clearFilters } = useStore();

  const results = useMemo(() => {
    const q = filters.query.trim().toLowerCase();
    const range = PRICE_RANGES.find((r) => r.id === filters.price) ?? PRICE_RANGES[0];
    const list = PRODUCTS.filter((p) => {
      if (filters.category === 'new-arrivals' ? !p.newArrival : filters.category !== 'all' && p.category !== filters.category) return false;
      if (p.price < range.min || p.price > range.max) return false;
      if (q && !`${p.name} ${p.description} ${p.category}`.toLowerCase().includes(q)) return false;
      return true;
    });
    const sorted = [...list];
    switch (filters.sort) {
      case 'price-asc': sorted.sort((a, b) => a.price - b.price); break;
      case 'price-desc': sorted.sort((a, b) => b.price - a.price); break;
      case 'rating': sorted.sort((a, b) => b.rating - a.rating); break;
      case 'newest': sorted.sort((a, b) => Number(!!b.newArrival) - Number(!!a.newArrival) || b.id - a.id); break;
    }
    return sorted;
  }, [filters]);

  const chips: { id: CategoryFilter; name: string }[] = [
    { id: 'all', name: 'All' },
    ...CATEGORIES.map((c) => ({ id: c.id as CategoryFilter, name: c.name })),
  ];
  const isFiltered = filters.query !== '' || filters.category !== 'all' || filters.price !== 'any' || filters.sort !== 'featured';

  return (
    <section id="shop" className="bg-cream py-16 lg:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <Reveal>
          <h2 className="section-title">The Full Collection</h2>
          <p className="section-sub">Search, filter and sort to find your style.</p>
        </Reveal>

        <div className="mt-9 flex flex-col gap-4">
          <div className="flex flex-col gap-3 md:flex-row">
            <div className="relative flex-1">
              <Icon name="search" className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-charcoal/50" />
              <input
                type="search"
                value={filters.query}
                onChange={(e) => setFilters({ query: e.target.value })}
                placeholder="Search styles"
                aria-label="Search styles"
                className="h-11 w-full rounded-full border border-beige bg-white pl-11 pr-4 text-base outline-none focus:border-gold sm:text-sm"
              />
            </div>
            <select aria-label="Filter by price" value={filters.price} onChange={(e) => setFilters({ price: e.target.value })} className={selectCls}>
              {PRICE_RANGES.map((r) => <option key={r.id} value={r.id}>{r.label}</option>)}
            </select>
            <select aria-label="Sort products" value={filters.sort} onChange={(e) => setFilters({ sort: e.target.value as SortKey })} className={selectCls}>
              {SORTS.map((s) => <option key={s.id} value={s.id}>{s.label}</option>)}
            </select>
          </div>

          <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 sm:mx-0 sm:flex-wrap sm:px-0" role="group" aria-label="Categories">
            {chips.map((c) => {
              const active = filters.category === c.id;
              return (
                <button
                  key={c.id}
                  type="button"
                  aria-pressed={active}
                  onClick={() => setFilters({ category: c.id })}
                  className={`min-h-[40px] shrink-0 rounded-full border px-4 text-sm transition ${
                    active ? 'border-maroon bg-maroon text-ivory' : 'border-beige bg-ivory text-charcoal/80 hover:border-gold'
                  }`}
                >
                  {c.name}
                </button>
              );
            })}
          </div>
        </div>

        <p className="mt-6 text-sm text-charcoal/65" aria-live="polite">
          Showing {results.length} {results.length === 1 ? 'style' : 'styles'}
        </p>

        <div className="mt-5">
          {results.length > 0 ? (
            <ProductGrid products={results} />
          ) : (
            <div className="rounded-2xl border border-dashed border-gold/60 bg-ivory px-6 py-14 text-center">
              <p className="font-display text-2xl text-burgundy">No styles match your search</p>
              <p className="mt-2 text-sm text-charcoal/65">Try a different word, or clear the filters to see everything.</p>
              <button type="button" className="btn-primary mt-6" onClick={clearFilters}>CLEAR FILTERS</button>
            </div>
          )}
        </div>

        {isFiltered && results.length > 0 && (
          <div className="mt-8 text-center">
            <button type="button" className="text-sm font-semibold text-maroon underline underline-offset-4" onClick={clearFilters}>
              Clear all filters
            </button>
          </div>
        )}
      </div>
    </section>
  );
}
