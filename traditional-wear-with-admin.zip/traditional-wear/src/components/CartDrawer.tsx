import { useStore } from '../context/StoreContext';
import { useOverlay } from '../hooks';
import { formatPrice, unitPrice } from '../utils';
import { Icon } from './Icons';

export default function CartDrawer() {
  const {
    drawerOpen, drawerTab, setDrawerTab, closeDrawer,
    cartLines, cartCount, cartTotal, updateQty, removeLine, orderOnWhatsApp,
    wishlistProducts, toggleWish, addToCart, wishlist,
  } = useStore();
  useOverlay(drawerOpen, closeDrawer);
  if (!drawerOpen) return null;

  const tab = (id: 'bag' | 'wishlist', label: string) => (
    <button
      type="button"
      role="tab"
      aria-selected={drawerTab === id}
      onClick={() => setDrawerTab(id)}
      className={`flex-1 border-b-2 py-3 text-sm font-semibold tracking-wide transition ${
        drawerTab === id ? 'border-maroon text-maroon' : 'border-transparent text-charcoal/55'
      }`}
    >
      {label}
    </button>
  );

  return (
    <div className="fixed inset-0 z-50" role="dialog" aria-modal="true" aria-label="Shopping bag and wishlist">
      <div className="anim-fade absolute inset-0 bg-burgundy/50" onClick={closeDrawer} />
      <aside className="anim-slide-in absolute inset-y-0 right-0 flex w-full max-w-md flex-col bg-ivory shadow-soft">
        <div className="flex items-center justify-between px-5 pt-4">
          <h2 className="font-display text-2xl font-semibold text-burgundy">Your Bag</h2>
          <button type="button" onClick={closeDrawer} aria-label="Close" className="flex h-11 w-11 items-center justify-center rounded-full hover:bg-cream">
            <Icon name="close" />
          </button>
        </div>
        <div className="flex px-5" role="tablist">
          {tab('bag', `Bag (${cartCount})`)}
          {tab('wishlist', `Wishlist (${wishlist.length})`)}
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4">
          {drawerTab === 'bag' &&
            (cartLines.length === 0 ? (
              <p className="py-16 text-center text-charcoal/65">Your bag is empty. Add a style you love and it will show up here.</p>
            ) : (
              <ul className="divide-y divide-beige">
                {cartLines.map(({ line, product }) => (
                  <li key={line.key} className="flex gap-4 py-4">
                    <img src={product.image} alt={product.name} width={80} height={107} loading="lazy" className="h-28 w-[84px] shrink-0 rounded-xl object-cover" />
                    <div className="flex min-w-0 flex-1 flex-col">
                      <div className="flex justify-between gap-2">
                        <h3 className="font-display text-lg font-semibold leading-tight text-burgundy">{product.name}</h3>
                        <button type="button" onClick={() => removeLine(line.key)} aria-label={`Remove ${product.name}`} className="-mr-2 -mt-2 flex h-10 w-10 shrink-0 items-center justify-center text-charcoal/50 hover:text-maroon">
                          <Icon name="close" className="h-4 w-4" />
                        </button>
                      </div>
                      <p className="text-xs text-charcoal/60">Size {line.size} · {line.color}</p>
                      <div className="mt-auto flex items-center justify-between pt-2">
                        <div className="flex items-center rounded-full border border-beige">
                          <button type="button" className="flex h-9 w-9 items-center justify-center" onClick={() => updateQty(line.key, -1)} aria-label="Decrease quantity"><Icon name="minus" className="h-4 w-4" /></button>
                          <span className="w-6 text-center text-sm font-semibold">{line.qty}</span>
                          <button type="button" className="flex h-9 w-9 items-center justify-center" onClick={() => updateQty(line.key, 1)} aria-label="Increase quantity"><Icon name="plus" className="h-4 w-4" /></button>
                        </div>
                        <span className="font-semibold">{formatPrice(unitPrice(product, line.size) * line.qty)}</span>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            ))}

          {drawerTab === 'wishlist' &&
            (wishlistProducts.length === 0 ? (
              <p className="py-16 text-center text-charcoal/65">Tap the heart on any style to save it here.</p>
            ) : (
              <ul className="divide-y divide-beige">
                {wishlistProducts.map((p) => (
                  <li key={p.id} className="flex gap-4 py-4">
                    <img src={p.image} alt={p.name} width={80} height={107} loading="lazy" className="h-28 w-[84px] shrink-0 rounded-xl object-cover" />
                    <div className="flex flex-1 flex-col">
                      <h3 className="font-display text-lg font-semibold leading-tight text-burgundy">{p.name}</h3>
                      <p className="mt-1 font-semibold">{formatPrice(p.price)}</p>
                      <div className="mt-auto flex gap-2 pt-2">
                        <button type="button" className="min-h-[40px] flex-1 rounded-full bg-maroon text-xs font-semibold tracking-wider text-ivory" onClick={() => addToCart(p)}>ADD TO CART</button>
                        <button type="button" className="flex h-10 w-10 items-center justify-center rounded-full border border-beige text-maroon" onClick={() => toggleWish(p.id)} aria-label={`Remove ${p.name} from wishlist`}>
                          <Icon name="heart" filled className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            ))}
        </div>

        {drawerTab === 'bag' && cartLines.length > 0 && (
          <div className="border-t border-beige bg-cream px-5 py-4">
            <div className="flex items-center justify-between text-base">
              <span className="font-semibold text-burgundy">Subtotal</span>
              <span className="text-lg font-semibold">{formatPrice(cartTotal)}</span>
            </div>
            <p className="mt-1 text-xs text-charcoal/60">Shipping and any offers are confirmed with you on WhatsApp.</p>
            <button type="button" onClick={orderOnWhatsApp} className="btn-primary mt-4 w-full gap-2">
              <Icon name="whatsapp" className="h-5 w-5" /> ORDER ON WHATSAPP
            </button>
          </div>
        )}
      </aside>
    </div>
  );
}
