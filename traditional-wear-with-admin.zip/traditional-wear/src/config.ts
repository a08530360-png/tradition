/* ==========================================================================
   STORE SETTINGS  -  edit everything about your business in this one file
   ========================================================================== */

export const STORE_NAME = 'Traditional Wear';
export const INSTAGRAM = '@traditional_wear_.1';

// NOTE: the live WhatsApp number is now set in the admin panel (Admin > Settings).
// The value below is only used as a fallback if no number has been saved there.
// WhatsApp number with country code, digits only. Example (India): '919876543210'
export const WHATSAPP_NUMBER = 'REPLACE_WITH_NUMBER';
export const EMAIL = 'REPLACE_WITH_EMAIL';
export const FACEBOOK_URL = 'REPLACE_WITH_FACEBOOK_URL';
// If left as-is, the link is built automatically from INSTAGRAM above.
export const INSTAGRAM_URL = 'REPLACE_WITH_INSTAGRAM_URL';

export const CURRENCY_SYMBOL = '₹';
