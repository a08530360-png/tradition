/* ==========================================================================
   IMAGES  -  every picture on the site is listed here.

   Right now these are on-brand illustrated placeholders (so the site works
   with no downloads). To use your real photos, replace any value with:
     - a file in the /public/images folder:   '/images/anarkali.jpg'
     - or a full web address:                 'https://your-cdn.com/photo.jpg'

   Tip: portrait photos (3:4 ratio, about 900 x 1200 px) look best for products.
   ========================================================================== */

type Shape = 'anarkali' | 'kurta' | 'lehenga' | 'suit';

const GARMENTS: Record<Shape, string> = {
  anarkali: 'M262 205h76l12 118 112 380q-162 46-324 0L250 323z',
  kurta: 'M244 200h112l44 92-26 26-18-32 10 384H234l10-384-18 32-26-26z',
  lehenga: 'M262 205h76l8 108H254zM232 330h136l152 376q-220 40-440 0z',
  suit: 'M244 200h112l44 92-26 26-18-32 10 384H234l10-384-18 32-26-26z',
};

function art(shape: Shape, bgTop: string, bgBottom: string, garment: string): string {
  const gold = '#D8BC85';
  const dupatta =
    shape === 'suit' || shape === 'lehenga'
      ? `<path d='M326 204l34 0 70 500-52 0z' fill='${gold}' fill-opacity='.55'/>`
      : '';
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 600 800'>
<defs>
<linearGradient id='g' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='${bgTop}'/><stop offset='1' stop-color='${bgBottom}'/></linearGradient>
<pattern id='p' width='44' height='44' patternUnits='userSpaceOnUse'><path d='M22 4l18 18-18 18L4 22z' fill='none' stroke='${gold}' stroke-opacity='.22'/></pattern>
</defs>
<rect width='600' height='800' fill='url(#g)'/>
<rect width='600' height='800' fill='url(#p)'/>
<path d='M120 800V330a180 180 0 0 1 360 0v470z' fill='none' stroke='${gold}' stroke-opacity='.55' stroke-width='2'/>
<circle cx='300' cy='146' r='36' fill='#FBF6EE' fill-opacity='.92'/>
<path d='${GARMENTS[shape]}' fill='${garment}'/>
${dupatta}
<path d='${GARMENTS[shape]}' fill='none' stroke='${gold}' stroke-width='3'/>
<path d='M262 232h76' stroke='${gold}' stroke-width='3'/>
</svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

export const IMAGES = {
  hero: art('anarkali', '#F1E2CC', '#D9BFA0', '#6B1526'),
  festive: art('lehenga', '#EBD6BE', '#C9A57F', '#4A0E1B'),

  categories: {
    'ethnic-dresses': art('anarkali', '#F3E6D3', '#DCC3A4', '#7A2233'),
    'traditional-wear': art('suit', '#EFE3D0', '#D3BC9C', '#2F5D50'),
    festive: art('lehenga', '#F0DDC6', '#CFA97C', '#6B1526'),
    'party-wear': art('anarkali', '#E9DCE0', '#C7A9B2', '#3B1230'),
    everyday: art('kurta', '#F5EEDF', '#E2D2B8', '#B98A5C'),
    'new-arrivals': art('kurta', '#EFE1CE', '#D6BC98', '#8A2B3E'),
  },

  products: {
    1: art('anarkali', '#F3E6D3', '#DCC3A4', '#7A2233'),
    2: art('suit', '#EFE3D0', '#D3BC9C', '#B98A5C'),
    3: art('suit', '#F1E4D2', '#D7BE9E', '#2F5D50'),
    4: art('anarkali', '#EEE0D0', '#D5B99A', '#8A5A6B'),
    5: art('kurta', '#F7F1E4', '#E5D6BD', '#EFE6D3'),
    6: art('lehenga', '#F0DDC6', '#CFA97C', '#6B1526'),
    7: art('lehenga', '#EEDFCB', '#D0B08A', '#3F6B5E'),
    8: art('kurta', '#F5EEDF', '#E2D2B8', '#5C7A9B'),
    9: art('anarkali', '#E9DCE0', '#C7A9B2', '#3B1230'),
    10: art('suit', '#F0E2CF', '#D4B996', '#7B1E3A'),
    11: art('suit', '#F4EBDC', '#DDCDB3', '#C9A7A0'),
    12: art('anarkali', '#E6D9DE', '#BFA0AB', '#4A0E1B'),
  } as Record<number, string>,

  instagram: [
    art('anarkali', '#F3E6D3', '#DCC3A4', '#7A2233'),
    art('kurta', '#F5EEDF', '#E2D2B8', '#B98A5C'),
    art('lehenga', '#F0DDC6', '#CFA97C', '#6B1526'),
    art('suit', '#EFE3D0', '#D3BC9C', '#2F5D50'),
    art('anarkali', '#E9DCE0', '#C7A9B2', '#3B1230'),
    art('kurta', '#EFE1CE', '#D6BC98', '#8A2B3E'),
  ],
};
