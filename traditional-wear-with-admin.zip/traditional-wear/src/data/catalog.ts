/* ==========================================================================
   LIVE CATALOG  -  where the website gets its products, categories and
   WhatsApp number.

   When the site is served by the Traditional Wear server (npm start), the
   current data from the admin panel is embedded in the page and used here.
   If that data is not available (for example the site is hosted as plain
   static files), the built-in data in products.ts / categories.ts / config.ts
   is used instead, so the website always works.
   ========================================================================== */

import type { Product } from '../types';
import { WHATSAPP_NUMBER } from '../config';
import { PRODUCTS as BUILT_IN_PRODUCTS } from './products';
import { CATEGORIES as BUILT_IN_CATEGORIES, type CategoryCard } from './categories';

export interface SiteSettings { whatsappNumber: string }

export let PRODUCTS: Product[] = BUILT_IN_PRODUCTS;
export let CATEGORIES: CategoryCard[] = BUILT_IN_CATEGORIES;
export let SETTINGS: SiteSettings = { whatsappNumber: WHATSAPP_NUMBER };

export const getProduct = (id: number) => PRODUCTS.find((p) => p.id === id);

interface Payload { settings?: { whatsappNumber?: unknown }; categories?: unknown; products?: unknown }

function apply(data: Payload | null): boolean {
  if (!data || !Array.isArray(data.products) || !Array.isArray(data.categories)) return false;
  const productsOk = data.products.every((p) => p && typeof p.id === 'number' && typeof p.name === 'string' && typeof p.image === 'string' && Array.isArray(p.sizes) && Array.isArray(p.colors));
  const categoriesOk = data.categories.every((c) => c && typeof c.id === 'string' && typeof c.name === 'string' && typeof c.image === 'string');
  if (!productsOk || !categoriesOk) return false;
  PRODUCTS = data.products as Product[];
  CATEGORIES = data.categories as CategoryCard[];
  const wa = typeof data.settings?.whatsappNumber === 'string' ? data.settings.whatsappNumber : '';
  SETTINGS = { whatsappNumber: wa || WHATSAPP_NUMBER }; // fall back to config.ts if none saved yet
  return true;
}

/** Call once before the first render. Never throws - on any problem the built-in data stays in use. */
export async function initCatalog(): Promise<void> {
  try {
    const embedded = JSON.parse(document.getElementById('store-data')?.textContent || 'null');
    if (apply(embedded)) return;
  } catch { /* fall through to fetching */ }

  try {
    const ctrl = new AbortController();
    const timer = window.setTimeout(() => ctrl.abort(), 4000);
    const res = await fetch('/api/store', { signal: ctrl.signal, headers: { Accept: 'application/json' } });
    window.clearTimeout(timer);
    if (res.ok && (res.headers.get('content-type') || '').includes('json')) apply(await res.json());
  } catch { /* no server data - keep built-in data */ }
}
