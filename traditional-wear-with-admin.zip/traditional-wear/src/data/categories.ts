import type { CategoryFilter } from '../types';
import { IMAGES } from './images';

export interface CategoryCard { id: Exclude<CategoryFilter, 'all'>; name: string; image: string }

export const CATEGORIES: CategoryCard[] = [
  { id: 'ethnic-dresses', name: 'Ethnic Dresses', image: IMAGES.categories['ethnic-dresses'] },
  { id: 'traditional-wear', name: 'Traditional Wear', image: IMAGES.categories['traditional-wear'] },
  { id: 'festive', name: 'Festive Collection', image: IMAGES.categories.festive },
  { id: 'party-wear', name: 'Party Wear', image: IMAGES.categories['party-wear'] },
  { id: 'everyday', name: 'Everyday Styles', image: IMAGES.categories.everyday },
  { id: 'new-arrivals', name: 'New Arrivals', image: IMAGES.categories['new-arrivals'] },
];

export const PRICE_RANGES = [
  { id: 'any', label: 'Any price', min: 0, max: Infinity },
  { id: 'u1500', label: 'Under ₹1,500', min: 0, max: 1499 },
  { id: '1500-2000', label: '₹1,500 – ₹2,000', min: 1500, max: 2000 },
  { id: '2000-2500', label: '₹2,000 – ₹2,500', min: 2001, max: 2500 },
  { id: 'o2500', label: 'Above ₹2,500', min: 2501, max: Infinity },
];
