import { StoreProvider } from './context/StoreContext';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import BenefitsBar from './components/BenefitsBar';
import CategorySection from './components/CategorySection';
import NewArrivals from './components/NewArrivals';
import FeaturedCollection from './components/FeaturedCollection';
import BestSellers from './components/BestSellers';
import Shop from './components/Shop';
import PromoBanner from './components/PromoBanner';
import WhyChooseUs from './components/WhyChooseUs';
import InstagramGallery from './components/InstagramGallery';
import Testimonials from './components/Testimonials';
import Newsletter from './components/Newsletter';
import FAQ from './components/FAQ';
import Footer from './components/Footer';
import CartDrawer from './components/CartDrawer';
import ProductModal from './components/ProductModal';
import WhatsAppButton from './components/WhatsAppButton';
import Toast from './components/Toast';

export default function App() {
  return (
    <StoreProvider>
      <Navbar />
      <main>
        <Hero />
        <BenefitsBar />
        <CategorySection />
        <NewArrivals />
        <FeaturedCollection />
        <BestSellers />
        <Shop />
        <PromoBanner />
        <WhyChooseUs />
        <InstagramGallery />
        <Testimonials />
        <Newsletter />
        <FAQ />
      </main>
      <Footer />
      <CartDrawer />
      <ProductModal />
      <WhatsAppButton />
      <Toast />
    </StoreProvider>
  );
}
