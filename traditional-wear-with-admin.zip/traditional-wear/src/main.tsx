import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { initCatalog } from './data/catalog';
import './index.css';

// Products, categories and the WhatsApp number come from the admin panel's data (see src/data/catalog.ts).
initCatalog().finally(() => {
  ReactDOM.createRoot(document.getElementById('root')!).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>,
  );
});
