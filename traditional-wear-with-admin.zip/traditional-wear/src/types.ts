// Categories are now managed from the admin panel, so an id is simply the category's short name (slug).
export type CategoryId = string;
export type CategoryFilter = 'all' | 'new-arrivals' | CategoryId;
export type SortKey = 'featured' | 'price-asc' | 'price-desc' | 'rating' | 'newest';

export interface ProductColor { name: string; hex: string }

export interface Product {
  id: number;
  name: string;
  category: CategoryId;
  price: number;
  originalPrice?: number;
  discount?: number; // percent
  image: string;
  rating: number;
  reviews: number;
  description: string;
  sizes: string[];
  colors: ProductColor[];
  badge?: 'NEW' | 'BEST SELLER' | 'SALE';
  newArrival?: boolean;
  bestSeller?: boolean;
  // Added by the admin panel (all optional, so older product data keeps working):
  images?: string[]; // all photos; `image` is always the first one
  available?: boolean; // false = shown as SOLD OUT
  sizePrices?: Record<string, number>; // optional price for specific sizes
}

export interface CartLine { key: string; productId: number; size: string; color: string; qty: number }

export interface Filters { query: string; category: CategoryFilter; price: string; sort: SortKey }
