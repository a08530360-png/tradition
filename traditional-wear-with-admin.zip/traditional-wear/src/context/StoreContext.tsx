import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import type { CartLine, CategoryFilter, Filters, Product } from '../types';
import { PRODUCTS, getProduct } from '../data/catalog';
import { STORE_NAME } from '../config';
import { formatPrice, scrollToId, unitPrice, whatsappHref } from '../utils';

const DEFAULT_FILTERS: Filters = { query: '', category: 'all', price: 'any', sort: 'featured' };

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}
function save(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage unavailable (private mode) - the cart still works for this visit */
  }
}

export interface ResolvedLine { line: CartLine; product: Product }
type DrawerTab = 'bag' | 'wishlist';

interface StoreValue {
  filters: Filters;
  setFilters: (patch: Partial<Filters>) => void;
  clearFilters: () => void;
  browse: (category: CategoryFilter) => void;
  searchShop: (query: string) => void;

  cartLines: ResolvedLine[];
  cartCount: number;
  cartTotal: number;
  addToCart: (product: Product, opts?: { size?: string; color?: string; qty?: number }) => void;
  updateQty: (key: string, delta: number) => void;
  removeLine: (key: string) => void;
  orderOnWhatsApp: () => void;

  wishlist: number[];
  wishlistProducts: Product[];
  isWished: (id: number) => boolean;
  toggleWish: (id: number) => void;

  drawerOpen: boolean;
  drawerTab: DrawerTab;
  openDrawer: (tab?: DrawerTab) => void;
  closeDrawer: () => void;
  setDrawerTab: (tab: DrawerTab) => void;

  quickView: Product | null;
  openQuickView: (p: Product) => void;
  closeQuickView: () => void;

  toast: { id: number; message: string } | null;
  showToast: (message: string) => void;
}

const Ctx = createContext<StoreValue | null>(null);

export function useStore(): StoreValue {
  const v = useContext(Ctx);
  if (!v) throw new Error('useStore must be used inside <StoreProvider>');
  return v;
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [filters, setFiltersState] = useState<Filters>(DEFAULT_FILTERS);
  const [cart, setCart] = useState<CartLine[]>(() => load<CartLine[]>('tw-cart', []));
  const [wishlist, setWishlist] = useState<number[]>(() => load<number[]>('tw-wishlist', []));
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [drawerTab, setDrawerTab] = useState<DrawerTab>('bag');
  const [quickView, setQuickView] = useState<Product | null>(null);
  const [toast, setToast] = useState<{ id: number; message: string } | null>(null);
  const toastTimer = useRef<number | undefined>(undefined);

  useEffect(() => save('tw-cart', cart), [cart]);
  useEffect(() => save('tw-wishlist', wishlist), [wishlist]);

  const showToast = useCallback((message: string) => {
    window.clearTimeout(toastTimer.current);
    setToast({ id: Date.now(), message });
    toastTimer.current = window.setTimeout(() => setToast(null), 2200);
  }, []);

  const setFilters = useCallback((patch: Partial<Filters>) => setFiltersState((f) => ({ ...f, ...patch })), []);
  const clearFilters = useCallback(() => setFiltersState(DEFAULT_FILTERS), []);

  const goToShop = () => window.setTimeout(() => scrollToId('shop'), 60);
  const browse = useCallback((category: CategoryFilter) => {
    setFiltersState({ ...DEFAULT_FILTERS, category });
    goToShop();
  }, []);
  const searchShop = useCallback((query: string) => {
    setFiltersState({ ...DEFAULT_FILTERS, query });
    goToShop();
  }, []);

  const addToCart = useCallback(
    (product: Product, opts?: { size?: string; color?: string; qty?: number }) => {
      if (product.available === false) { showToast('Sorry, this style is sold out'); return; }
      const size = opts?.size ?? product.sizes[0];
      const color = opts?.color ?? product.colors[0]?.name ?? '';
      const qty = opts?.qty ?? 1;
      const key = `${product.id}|${size}|${color}`;
      setCart((prev) => {
        const existing = prev.find((l) => l.key === key);
        if (existing) return prev.map((l) => (l.key === key ? { ...l, qty: Math.min(10, l.qty + qty) } : l));
        return [...prev, { key, productId: product.id, size, color, qty }];
      });
      showToast('Added to your cart ✓');
    },
    [showToast],
  );

  const updateQty = useCallback((key: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((l) => (l.key === key ? { ...l, qty: Math.min(10, l.qty + delta) } : l))
        .filter((l) => l.qty > 0),
    );
  }, []);
  const removeLine = useCallback((key: string) => setCart((prev) => prev.filter((l) => l.key !== key)), []);

  const cartLines = useMemo<ResolvedLine[]>(
    () =>
      cart.flatMap((line) => {
        const product = getProduct(line.productId);
        return product ? [{ line, product }] : [];
      }),
    [cart],
  );
  const cartCount = cartLines.reduce((n, { line }) => n + line.qty, 0);
  const cartTotal = cartLines.reduce((n, { line, product }) => n + line.qty * unitPrice(product, line.size), 0);

  const orderOnWhatsApp = useCallback(() => {
    if (cartLines.length === 0) return;
    const lines = cartLines.map(
      ({ line, product }, i) =>
        `${i + 1}. ${product.name} (Size ${line.size}, ${line.color}) x ${line.qty} - ${formatPrice(unitPrice(product, line.size) * line.qty)}`,
    );
    const text = `Hi ${STORE_NAME}! I'd like to order:\n\n${lines.join('\n')}\n\nTotal: ${formatPrice(cartTotal)}`;
    window.open(whatsappHref(text), '_blank', 'noopener,noreferrer');
  }, [cartLines, cartTotal]);

  const isWished = useCallback((id: number) => wishlist.includes(id), [wishlist]);
  const toggleWish = useCallback(
    (id: number) => {
      const has = wishlist.includes(id);
      setWishlist((prev) => (has ? prev.filter((x) => x !== id) : [...prev, id]));
      showToast(has ? 'Removed from your wishlist' : 'Saved to your wishlist ♥');
    },
    [wishlist, showToast],
  );
  const wishlistProducts = useMemo(
    () => wishlist.flatMap((id) => {
      const p = getProduct(id);
      return p ? [p] : [];
    }),
    [wishlist],
  );

  const value: StoreValue = {
    filters, setFilters, clearFilters, browse, searchShop,
    cartLines, cartCount, cartTotal, addToCart, updateQty, removeLine, orderOnWhatsApp,
    wishlist, wishlistProducts, isWished, toggleWish,
    drawerOpen, drawerTab, setDrawerTab,
    openDrawer: (tab = 'bag') => { setDrawerTab(tab); setDrawerOpen(true); },
    closeDrawer: () => setDrawerOpen(false),
    quickView,
    openQuickView: setQuickView,
    closeQuickView: () => setQuickView(null),
    toast, showToast,
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export { PRODUCTS };
