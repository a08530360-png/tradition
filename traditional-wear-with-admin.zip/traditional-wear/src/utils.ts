import { CURRENCY_SYMBOL, EMAIL, FACEBOOK_URL, INSTAGRAM, INSTAGRAM_URL } from './config';
import { SETTINGS } from './data/catalog';
import type { Product } from './types';

export const formatPrice = (n: number) => `${CURRENCY_SYMBOL}${n.toLocaleString('en-IN')}`;

const isSet = (v: string) => v.trim() !== '' && !v.startsWith('REPLACE_WITH');

export const instagramHref = () =>
  isSet(INSTAGRAM_URL) ? INSTAGRAM_URL : `https://www.instagram.com/${INSTAGRAM.replace('@', '')}/`;
export const facebookHref = () => (isSet(FACEBOOK_URL) ? FACEBOOK_URL : '#');
export const emailHref = () => (isSet(EMAIL) ? `mailto:${EMAIL}` : '#');
export const whatsappHref = (text?: string) => {
  // The number comes from the admin panel (Settings). config.ts is only the fallback.
  const num = isSet(SETTINGS.whatsappNumber) ? SETTINGS.whatsappNumber.replace(/\D/g, '') : '';
  return `https://wa.me/${num}${text ? `?text=${encodeURIComponent(text)}` : ''}`;
};

export const scrollToId = (id: string) => {
  if (id === 'home') window.scrollTo({ top: 0, behavior: 'smooth' });
  else document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
};

/** Price for a chosen size (some products price certain sizes differently). */
export const unitPrice = (p: Product, size?: string) => (size ? p.sizePrices?.[size] : undefined) ?? p.price;

/** Lowest and highest price across all sizes of a product. */
export const priceSpread = (p: Product) => {
  const all = p.sizePrices ? p.sizes.map((s) => unitPrice(p, s)) : [p.price];
  return { min: Math.min(...all), max: Math.max(...all) };
};
