import { createContext, useContext } from 'react';
import type { AdminData } from './types';

export interface DataValue { data: AdminData; setData: (d: AdminData) => void; reload: () => Promise<void> }
export const DataCtx = createContext<DataValue | null>(null);
export function useData(): DataValue {
  const v = useContext(DataCtx);
  if (!v) throw new Error('useData outside provider');
  return v;
}
