import { useState, type FormEvent } from 'react';
import { api, type SessionInfo } from '../api';
import { Icon, Spinner } from '../ui';

export default function Login({ session, notice, onSuccess }: { session: SessionInfo; notice: string; onSuccess: () => void }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password) { setError('Enter your username and password.'); return; }
    setBusy(true); setError('');
    try { await api.login(username.trim(), password); onSuccess(); }
    catch (err) { setError((err as Error).message); setPassword(''); }
    finally { setBusy(false); }
  };

  return (
    <div className="flex min-h-dvh items-center justify-center bg-gradient-to-b from-burgundy to-maroon px-4 py-10">
      <div className="w-full max-w-sm">
        <div className="mb-6 text-center text-ivory">
          <p className="font-display text-3xl font-semibold">Traditional Wear</p>
          <p className="mt-1 text-xs tracking-[0.25em] text-gold-light">ADMIN PANEL</p>
        </div>

        <div className="card p-6 shadow-xl">
          <h1 className="font-display text-2xl font-semibold text-burgundy">Sign in</h1>

          {!session.configured ? (
            <div className="mt-4 rounded-xl bg-amber-50 p-4 text-sm leading-relaxed text-amber-900">
              <p className="font-semibold">Admin login is not set up yet.</p>
              <p className="mt-1">On the computer or server where the website runs, open a terminal in the project folder and run:</p>
              <p className="mt-2 rounded-lg bg-white/70 px-3 py-2 font-mono text-[13px]">npm run setup</p>
              <p className="mt-2">Then restart the website and reload this page.</p>
            </div>
          ) : (
            <form onSubmit={submit} className="mt-4 space-y-4" noValidate>
              {notice && <p className="rounded-xl bg-amber-50 px-3 py-2 text-sm text-amber-900">{notice}</p>}
              <div>
                <label className="label" htmlFor="username">Username</label>
                <input id="username" className="input" autoComplete="username" autoCapitalize="none" autoCorrect="off" value={username} onChange={(e) => setUsername(e.target.value)} autoFocus />
              </div>
              <div>
                <label className="label" htmlFor="password">Password</label>
                <div className="relative">
                  <input id="password" className="input pr-14" type={show ? 'text' : 'password'} autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} />
                  <button type="button" onClick={() => setShow((s) => !s)} aria-label={show ? 'Hide password' : 'Show password'} className="absolute inset-y-0 right-0 flex w-12 items-center justify-center text-charcoal/55"><Icon name="eye" className="h-5 w-5" /></button>
                </div>
              </div>
              {error && <p className="error-text" role="alert">{error}</p>}
              <button type="submit" className="btn-primary w-full" disabled={busy}>{busy && <Spinner className="h-4 w-4" />} Sign in</button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
