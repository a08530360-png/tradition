import { useState, type FormEvent } from 'react';
import { api } from '../api';
import { useData } from '../data';
import { Field, Icon, PageHeader, Spinner, useToast } from '../ui';
import type { FieldErrors } from '../types';

const normalize = (raw: string) => {
  let v = raw.trim().replace(/[\s\-().]/g, '');
  if (v.startsWith('+')) v = v.slice(1);
  else if (v.startsWith('00')) v = v.slice(2);
  return v;
};

export default function Settings() {
  const { data, setData } = useData();
  const toast = useToast();
  const [value, setValue] = useState(data.settings.whatsappNumber);
  const [busy, setBusy] = useState(false);
  const [errors, setErrors] = useState<FieldErrors>({});

  const digits = normalize(value);
  const looksValid = /^[1-9]\d{9,14}$/.test(digits);
  const unchanged = digits === data.settings.whatsappNumber;

  const save = async (e: FormEvent) => {
    e.preventDefault();
    setErrors({}); setBusy(true);
    try {
      setData(await api.saveSettings(value));
      setValue(digits);
      toast('WhatsApp number saved. The website now uses it everywhere.');
    } catch (err) {
      const ex = err as { fields?: FieldErrors; message: string };
      if (ex.fields) setErrors(ex.fields); else toast(ex.message, 'error');
    } finally { setBusy(false); }
  };

  return (
    <div className="max-w-xl">
      <PageHeader title="WhatsApp / Website Settings" subtitle="Settings that apply to the whole website." />

      <form onSubmit={save} className="card space-y-5 p-5 sm:p-6" noValidate>
        <div className="flex items-start gap-3">
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#25D366]/15 text-[#128C7E]"><Icon name="chat" /></span>
          <div>
            <h2 className="font-display text-xl font-semibold text-burgundy">WhatsApp number</h2>
            <p className="text-sm text-charcoal/65">Used for the green chat button, the footer links and the “Order on WhatsApp” button in the cart.</p>
          </div>
        </div>

        <Field label="Number (with country code)" error={errors.whatsappNumber} htmlFor="wa" hint="Country code first, then the number, no spaces. For India: 91 followed by the 10-digit number, e.g. 919876543210.">
          <input id="wa" className={`input ${errors.whatsappNumber ? 'input-error' : ''}`} inputMode="tel" autoComplete="off" placeholder="919876543210" value={value} onChange={(e) => setValue(e.target.value)} />
        </Field>

        {digits && (
          <div className={`rounded-xl px-4 py-3 text-sm ${looksValid ? 'bg-emerald-50 text-emerald-900' : 'bg-amber-50 text-amber-900'}`}>
            {looksValid ? (
              <>
                Customers will message <strong>+{digits}</strong>.{' '}
                <a className="font-semibold underline" href={`https://wa.me/${digits}`} target="_blank" rel="noopener noreferrer">Test this number in WhatsApp</a>
              </>
            ) : (
              <>This does not look like a full number yet. Include the country code (for India, start with 91).</>
            )}
          </div>
        )}

        <button type="submit" className="btn-primary w-full sm:w-auto" disabled={busy || !digits || unchanged}>
          {busy && <Spinner className="h-4 w-4" />} Save number
        </button>
      </form>
    </div>
  );
}
