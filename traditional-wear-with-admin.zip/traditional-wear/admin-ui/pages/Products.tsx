import { useMemo, useState } from 'react';
import { api } from '../api';
import { useData } from '../data';
import { Link, go, type Route } from '../nav';
import { ConfirmDialog, Icon, PageHeader, Switch, formatINR, useToast } from '../ui';
import type { Product } from '../types';

export default function Products({ route }: { route: Route }) {
  const { data, setData } = useData();
  const toast = useToast();
  const category = route.query.get('category') || 'all';
  const [query, setQuery] = useState('');
  const [deleting, setDeleting] = useState<Product | null>(null);
  const [busy, setBusy] = useState(false);
  const [pending, setPending] = useState<number | null>(null);

  const catName = (id: string) => data.categories.find((c) => c.id === id)?.name ?? id;
  const realCategories = data.categories.filter((c) => !c.system);

  const list = useMemo(() => {
    const q = query.trim().toLowerCase();
    return data.products.filter((p) => (category === 'all' || p.category === category) && (!q || p.name.toLowerCase().includes(q)));
  }, [data.products, category, query]);

  const setCategory = (id: string) => go(id === 'all' ? '/products' : `/products?category=${id}`);

  const toggle = async (p: Product, available: boolean) => {
    setPending(p.id);
    try { setData(await api.setAvailability(p.id, available)); toast(available ? `“${p.name}” is available again.` : `“${p.name}” now shows as SOLD OUT.`); }
    catch (e) { toast((e as Error).message, 'error'); }
    finally { setPending(null); }
  };

  const remove = async () => {
    if (!deleting) return;
    setBusy(true);
    try { setData(await api.deleteProduct(deleting.id)); toast('Product deleted.'); }
    catch (e) { toast((e as Error).message, 'error'); }
    finally { setBusy(false); setDeleting(null); }
  };

  return (
    <div>
      <PageHeader
        title="Products"
        subtitle={`${data.products.length} product${data.products.length === 1 ? '' : 's'} on your website.`}
        actions={<Link to={category !== 'all' ? `/products/new?category=${category}` : '/products/new'} className="btn-primary"><Icon name="plus" /> Add Product</Link>}
      />

      <div className="mb-5 flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1">
          <Icon name="search" className="pointer-events-none absolute left-3.5 top-1/2 h-5 w-5 -translate-y-1/2 text-charcoal/40" />
          <input className="input pl-11" type="search" placeholder="Search products" aria-label="Search products" value={query} onChange={(e) => setQuery(e.target.value)} />
        </div>
        <select className="input sm:w-64" aria-label="Filter by category" value={category} onChange={(e) => setCategory(e.target.value)}>
          <option value="all">All categories</option>
          {realCategories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>

      {list.length === 0 ? (
        <div className="card p-10 text-center">
          <p className="font-display text-xl text-burgundy">{data.products.length === 0 ? 'No products yet' : 'No products found'}</p>
          <p className="mt-1 text-sm text-charcoal/65">{data.products.length === 0 ? 'Add your first product to see it on your website.' : 'Try another search or category.'}</p>
        </div>
      ) : (
        <ul className="space-y-3">
          {list.map((p) => {
            const soldOut = p.available === false;
            return (
              <li key={p.id} className="card flex flex-wrap items-center gap-x-4 gap-y-3 p-3 sm:flex-nowrap">
                <Link to={`/products/${p.id}`} className="flex min-w-0 flex-1 items-center gap-3">
                  <img src={p.image} alt="" className={`h-24 w-[72px] shrink-0 rounded-xl bg-beige object-cover ${soldOut ? 'opacity-60' : ''}`} />
                  <div className="min-w-0">
                    <p className="truncate font-display text-lg font-semibold leading-tight text-burgundy">{p.name}</p>
                    <p className="text-sm text-charcoal/65">{catName(p.category)}</p>
                    <p className="mt-1 text-base font-semibold">{formatINR(p.price)}{p.sizePrices && <span className="ml-1.5 text-xs font-medium text-charcoal/55">(size prices vary)</span>}</p>
                    <p className="text-xs text-charcoal/55">{p.images?.length ?? 1} photo{(p.images?.length ?? 1) === 1 ? '' : 's'} · {p.colors.length} colour{p.colors.length === 1 ? '' : 's'} · {p.sizes.length} size{p.sizes.length === 1 ? '' : 's'}</p>
                  </div>
                </Link>

                <div className="flex w-full items-center justify-between gap-3 border-t border-beige/60 pt-3 sm:w-auto sm:border-0 sm:pt-0">
                  <label className="flex items-center gap-2.5 text-sm font-semibold">
                    <Switch checked={!soldOut} disabled={pending === p.id} onChange={(v) => toggle(p, v)} label={`${p.name} available`} />
                    <span className={soldOut ? 'text-red-700' : 'text-emerald-700'}>{soldOut ? 'Sold out' : 'Available'}</span>
                  </label>
                  <div className="flex gap-2">
                    <Link to={`/products/${p.id}`} className="btn-secondary btn-sm" aria-label={`Edit ${p.name}`}><Icon name="pencil" className="h-4 w-4" /> Edit</Link>
                    <button type="button" className="btn-secondary btn-sm !px-3 text-red-700 hover:!border-red-400" onClick={() => setDeleting(p)} aria-label={`Delete ${p.name}`}><Icon name="trash" className="h-4 w-4" /></button>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}

      {deleting && (
        <ConfirmDialog
          title="Delete this product?"
          confirmLabel="Yes, delete product"
          busy={busy}
          onConfirm={remove}
          onCancel={() => setDeleting(null)}
          message={<><p><strong>{deleting.name}</strong> will be removed from your website, including its photos. This cannot be undone.</p><p className="mt-3 text-sm text-charcoal/65">Just want to hide it for now? Cancel and switch it to “Sold out” instead.</p></>}
        />
      )}
    </div>
  );
}
