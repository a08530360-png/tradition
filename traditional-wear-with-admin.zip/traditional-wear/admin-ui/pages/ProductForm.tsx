import { useEffect, useMemo, useRef, useState } from 'react';
import { api } from '../api';
import { useData } from '../data';
import { go, setNavGuard, type Route } from '../nav';
import { ConfirmDialog, Field, Icon, PageHeader, Spinner, Switch, useToast } from '../ui';
import { PhotoGrid } from '../components/Photos';
import type { FieldErrors, Product } from '../types';

const STANDARD_SIZES = ['XS', 'S', 'M', 'L', 'XL', 'XXL', '3XL', 'Free Size'];
const DEFAULT_SIZES = ['S', 'M', 'L', 'XL', 'XXL'];
const COLOR_PRESETS = [
  ['Maroon', '#7A2233'], ['Red', '#C0392B'], ['Pink', '#E58FA8'], ['Rose', '#C9A7A0'], ['Orange', '#E07B39'], ['Mustard', '#D4A52A'],
  ['Yellow', '#F2D04B'], ['Green', '#2F7D5B'], ['Emerald', '#2F5D50'], ['Teal', '#2A8A8A'], ['Sky Blue', '#7FB4DB'], ['Navy', '#1F2A44'],
  ['Purple', '#6B3FA0'], ['Wine', '#5A1A2A'], ['Black', '#1E1E1E'], ['White', '#FFFFFF'], ['Ivory', '#EFE6D3'], ['Gold', '#B8965A'],
] as const;

interface FormState {
  name: string; category: string; description: string;
  price: string; originalPrice: string;
  images: string[];
  colors: { name: string; hex: string }[];
  sizes: string[];
  sizePrices: Record<string, string>;
  badge: string; newArrival: boolean; bestSeller: boolean; available: boolean;
}

const fromProduct = (p: Product): FormState => ({
  name: p.name, category: p.category, description: p.description,
  price: String(p.price), originalPrice: p.originalPrice ? String(p.originalPrice) : '',
  images: p.images?.length ? p.images : [p.image],
  colors: p.colors.map((c) => ({ ...c })),
  sizes: [...p.sizes],
  sizePrices: Object.fromEntries(Object.entries(p.sizePrices ?? {}).map(([k, v]) => [k, String(v)])),
  badge: p.badge ?? '', newArrival: !!p.newArrival, bestSeller: !!p.bestSeller, available: p.available !== false,
});

const digitsOnly = (v: string) => v.replace(/[^\d]/g, '').slice(0, 7);

function Section({ n, title, help, children }: { n: number; title: string; help?: string; children: React.ReactNode }) {
  return (
    <section className="card p-5 sm:p-6">
      <div className="mb-4 flex items-start gap-3">
        <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-maroon text-sm font-semibold text-ivory">{n}</span>
        <div>
          <h2 className="font-display text-xl font-semibold leading-7 text-burgundy">{title}</h2>
          {help && <p className="text-sm text-charcoal/60">{help}</p>}
        </div>
      </div>
      {children}
    </section>
  );
}

export default function ProductForm({ route }: { route: Route }) {
  const { data, setData } = useData();
  const toast = useToast();
  const idPart = route.parts[1];
  const editingId = idPart === 'new' ? null : Number(idPart);
  const existing = editingId ? data.products.find((p) => p.id === editingId) : undefined;
  const realCategories = data.categories.filter((c) => !c.system);

  const initial = useMemo<FormState>(() => {
    if (existing) return fromProduct(existing);
    const wanted = route.query.get('category') || '';
    return {
      name: '', category: realCategories.some((c) => c.id === wanted) ? wanted : '', description: '',
      price: '', originalPrice: '', images: [], colors: [], sizes: DEFAULT_SIZES, sizePrices: {},
      badge: '', newArrival: false, bestSeller: false, available: true,
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [idPart]);

  const [f, setF] = useState<FormState>(initial);
  const [errors, setErrors] = useState<FieldErrors>({});
  const [busy, setBusy] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [showSizePrices, setShowSizePrices] = useState(Object.keys(initial.sizePrices).length > 0);
  const [customSize, setCustomSize] = useState('');
  const savedRef = useRef(false);
  const snapshot = useRef(JSON.stringify(initial));
  const dirty = JSON.stringify(f) !== snapshot.current;

  const set = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setF((s) => ({ ...s, [key]: value }));
    setErrors((e) => (e[key] ? { ...e, [key]: '' } : e));
  };

  // Warn before leaving with unsaved changes
  useEffect(() => {
    if (!dirty || savedRef.current) { setNavGuard(null); return; }
    setNavGuard(() => window.confirm('You have unsaved changes. Leave without saving?'));
    const warn = (e: BeforeUnloadEvent) => { e.preventDefault(); e.returnValue = ''; };
    window.addEventListener('beforeunload', warn);
    return () => { window.removeEventListener('beforeunload', warn); setNavGuard(null); };
  }, [dirty]);

  if (editingId && !existing) {
    return (
      <div className="card p-8 text-center">
        <p className="font-display text-xl text-burgundy">This product no longer exists.</p>
        <button type="button" className="btn-primary mt-5" onClick={() => go('/products')}>Back to products</button>
      </div>
    );
  }

  // ---------------------------------------------------------------- sizes
  const toggleSize = (s: string) => set('sizes', f.sizes.includes(s) ? f.sizes.filter((x) => x !== s) : [...f.sizes, s]);
  const addCustomSize = () => {
    const s = customSize.replace(/\s+/g, ' ').trim();
    if (!s) return;
    if (s.length > 14) { setErrors((e) => ({ ...e, sizes: 'A size name can have at most 14 characters.' })); return; }
    if (!f.sizes.some((x) => x.toLowerCase() === s.toLowerCase())) set('sizes', [...f.sizes, s]);
    setCustomSize('');
  };
  const orderedSizes = [...STANDARD_SIZES.filter((s) => f.sizes.includes(s)), ...f.sizes.filter((s) => !STANDARD_SIZES.includes(s))];
  const customSizes = f.sizes.filter((s) => !STANDARD_SIZES.includes(s));

  // ---------------------------------------------------------------- colours
  const addColor = (name = '', hex = '#7A2233') => {
    if (name && f.colors.some((c) => c.name.toLowerCase() === name.toLowerCase())) return;
    set('colors', [...f.colors, { name, hex }]);
  };
  const editColor = (i: number, patch: Partial<{ name: string; hex: string }>) => set('colors', f.colors.map((c, k) => (k === i ? { ...c, ...patch } : c)));

  // ---------------------------------------------------------------- validate + save
  const validate = (): FieldErrors => {
    const e: FieldErrors = {};
    if (!f.name.trim()) e.name = 'Enter the product name.';
    else if (f.name.trim().length < 2) e.name = 'Product name must be at least 2 characters.';
    if (!f.category) e.category = 'Choose a category.';
    const price = Number(f.price);
    if (!f.price) e.price = 'Enter the price.';
    else if (!Number.isInteger(price) || price < 1) e.price = 'Enter a valid price, for example 1499.';
    if (f.originalPrice) {
      const op = Number(f.originalPrice);
      if (!Number.isInteger(op) || op < 1) e.originalPrice = 'Enter a valid price, or leave this empty.';
      else if (!e.price && op <= price) e.originalPrice = 'The old price must be higher than the selling price.';
    }
    if (f.images.length === 0) e.images = 'Add at least one photo.';
    if (f.sizes.length === 0) e.sizes = 'Choose at least one size (use “Free Size” if there is only one).';
    if (f.colors.length === 0) e.colors = 'Add at least one colour.';
    else if (f.colors.some((c) => !c.name.trim())) e.colors = 'Every colour needs a name.';
    else if (new Set(f.colors.map((c) => c.name.trim().toLowerCase())).size !== f.colors.length) e.colors = 'A colour name is used twice.';
    if (showSizePrices) {
      const bad = orderedSizes.find((s) => f.sizePrices[s] && (!Number.isInteger(Number(f.sizePrices[s])) || Number(f.sizePrices[s]) < 1));
      if (bad) e.sizePrices = `Check the price for size ${bad}.`;
    }
    return e;
  };

  const save = async () => {
    const e = validate();
    setErrors(e);
    const first = Object.keys(e)[0];
    if (first) {
      toast('Please fix the highlighted fields.', 'error');
      document.getElementById(`field-${first}`)?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }
    setBusy(true);
    try {
      const sizePrices = showSizePrices ? Object.fromEntries(orderedSizes.filter((s) => f.sizePrices[s]).map((s) => [s, f.sizePrices[s]])) : {};
      const res = await api.saveProduct(editingId, { ...f, sizes: orderedSizes, sizePrices });
      savedRef.current = true;
      setNavGuard(null);
      setData({ settings: res.settings, categories: res.categories, products: res.products });
      toast(editingId ? 'Product saved. Your website is updated.' : 'Product added. It is now live on your website.');
      go('/products');
    } catch (err) {
      const ex = err as { fields?: FieldErrors; message: string };
      if (ex.fields) {
        setErrors(ex.fields);
        const firstKey = Object.keys(ex.fields)[0];
        document.getElementById(`field-${firstKey}`)?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      toast(ex.message, 'error');
    } finally { setBusy(false); }
  };

  const remove = async () => {
    if (!editingId) return;
    setBusy(true);
    try {
      const next = await api.deleteProduct(editingId);
      savedRef.current = true; setNavGuard(null);
      setData(next); toast('Product deleted.'); go('/products');
    } catch (err) { toast((err as Error).message, 'error'); setConfirmDelete(false); }
    finally { setBusy(false); }
  };

  const cancel = () => go('/products');

  const priceNum = Number(f.price), oldNum = Number(f.originalPrice);
  const discount = f.price && f.originalPrice && oldNum > priceNum ? Math.round((1 - priceNum / oldNum) * 100) : 0;
  const check = 'h-6 w-6 shrink-0 accent-[#6B1526]';

  return (
    <div className="mx-auto max-w-3xl">
      <button type="button" onClick={cancel} className="mb-3 inline-flex min-h-[40px] items-center gap-1 text-sm font-semibold text-maroon"><Icon name="left" className="h-4 w-4" /> All products</button>
      <PageHeader title={editingId ? 'Edit Product' : 'Add Product'} subtitle={editingId ? 'Change anything and press Save. The website updates straight away.' : 'Fill in the details and press Save. The product appears on your website straight away.'} />

      <div className="space-y-5">
        <Section n={1} title="Basic details">
          <div className="space-y-5">
            <div id="field-name">
              <Field label="Product name" error={errors.name} htmlFor="name">
                <input id="name" className={`input ${errors.name ? 'input-error' : ''}`} maxLength={120} placeholder="e.g. Royal Anarkali Dress" value={f.name} onChange={(e) => set('name', e.target.value)} />
              </Field>
            </div>
            <div id="field-category">
              <Field label="Category" error={errors.category} htmlFor="category">
                <select id="category" className={`input ${errors.category ? 'input-error' : ''}`} value={f.category} onChange={(e) => set('category', e.target.value)}>
                  <option value="">Choose a category…</option>
                  {realCategories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </Field>
            </div>
            <div id="field-description">
              <Field label="Description / details (optional)" error={errors.description} htmlFor="description" hint="Fabric, fit, occasion, care instructions…">
                <textarea id="description" className={`input min-h-[120px] py-3 ${errors.description ? 'input-error' : ''}`} maxLength={2000} value={f.description} onChange={(e) => set('description', e.target.value)} />
              </Field>
            </div>
          </div>
        </Section>

        <Section n={2} title="Price">
          <div className="grid gap-5 sm:grid-cols-2">
            <div id="field-price">
              <Field label="Price (₹)" error={errors.price} htmlFor="price">
                <input id="price" className={`input ${errors.price ? 'input-error' : ''}`} inputMode="numeric" placeholder="1499" value={f.price} onChange={(e) => set('price', digitsOnly(e.target.value))} />
              </Field>
            </div>
            <div id="field-originalPrice">
              <Field label="Old price (optional)" error={errors.originalPrice} htmlFor="old" hint={discount ? `Shown crossed out, with “${discount}% off”.` : 'Only fill this in if the product is on sale.'}>
                <input id="old" className={`input ${errors.originalPrice ? 'input-error' : ''}`} inputMode="numeric" placeholder="1999" value={f.originalPrice} onChange={(e) => set('originalPrice', digitsOnly(e.target.value))} />
              </Field>
            </div>
          </div>
        </Section>

        <Section n={3} title="Photos" help="Add one or more photos. Customers can flip through them on the product page.">
          <div id="field-images"><PhotoGrid images={f.images} onChange={(v) => set('images', v)} error={errors.images} /></div>
        </Section>

        <Section n={4} title="Colours" help="Add the colours this product comes in.">
          <div id="field-colors">
            {f.colors.length > 0 && (
              <ul className="mb-4 space-y-2.5">
                {f.colors.map((c, i) => (
                  <li key={i} className="flex items-center gap-2.5">
                    <input type="color" aria-label={`Colour swatch ${i + 1}`} value={c.hex} onChange={(e) => editColor(i, { hex: e.target.value.toUpperCase() })} className="h-11 w-11 shrink-0 cursor-pointer rounded-full border border-beige bg-white p-0.5" />
                    <input className="input" aria-label={`Colour name ${i + 1}`} placeholder="Colour name, e.g. Maroon" maxLength={30} value={c.name} onChange={(e) => editColor(i, { name: e.target.value })} />
                    <button type="button" aria-label={`Remove colour ${c.name || i + 1}`} onClick={() => set('colors', f.colors.filter((_, k) => k !== i))} className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-beige text-red-700 hover:border-red-400"><Icon name="trash" className="h-4 w-4" /></button>
                  </li>
                ))}
              </ul>
            )}
            <p className="mb-2 text-sm font-semibold text-burgundy">Tap to add a colour:</p>
            <div className="flex flex-wrap gap-2">
              {COLOR_PRESETS.map(([name, hex]) => {
                const on = f.colors.some((c) => c.name.toLowerCase() === name.toLowerCase());
                return (
                  <button key={name} type="button" onClick={() => addColor(name, hex)} disabled={on} className="inline-flex min-h-[40px] items-center gap-2 rounded-full border border-beige bg-white px-3 text-sm transition hover:border-gold disabled:opacity-40">
                    <span className="h-4 w-4 rounded-full border border-charcoal/20" style={{ backgroundColor: hex }} /> {name}
                  </button>
                );
              })}
            </div>
            <button type="button" className="btn-secondary btn-sm mt-3" onClick={() => addColor()}><Icon name="plus" className="h-4 w-4" /> Other colour</button>
            {errors.colors && <p className="error-text" role="alert">{errors.colors}</p>}
          </div>
        </Section>

        <Section n={5} title="Sizes" help="Tap the sizes that are available.">
          <div id="field-sizes">
            <div className="flex flex-wrap gap-2">
              {STANDARD_SIZES.map((s) => {
                const on = f.sizes.includes(s);
                return (
                  <button key={s} type="button" aria-pressed={on} onClick={() => toggleSize(s)} className={`min-h-[44px] min-w-[52px] rounded-full border px-4 text-sm font-semibold transition ${on ? 'border-maroon bg-maroon text-ivory' : 'border-beige bg-white text-charcoal hover:border-gold'}`}>{s}</button>
                );
              })}
              {customSizes.map((s) => (
                <button key={s} type="button" onClick={() => toggleSize(s)} aria-label={`Remove size ${s}`} className="inline-flex min-h-[44px] items-center gap-1.5 rounded-full border border-maroon bg-maroon px-4 text-sm font-semibold text-ivory">{s} <Icon name="x" className="h-3.5 w-3.5" /></button>
              ))}
            </div>
            <div className="mt-3 flex gap-2">
              <input className="input" aria-label="Add another size" placeholder="Other size, e.g. 38 or 2-3 yrs" maxLength={14} value={customSize} onChange={(e) => setCustomSize(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addCustomSize(); } }} />
              <button type="button" className="btn-secondary shrink-0" onClick={addCustomSize}>Add</button>
            </div>
            {errors.sizes && <p className="error-text" role="alert">{errors.sizes}</p>}

            {orderedSizes.length > 0 && (
              <div className="mt-5 rounded-xl bg-cream/60 p-4">
                <label className="flex min-h-[44px] cursor-pointer items-center gap-3 text-sm font-semibold text-burgundy">
                  <input type="checkbox" className={check} checked={showSizePrices} onChange={(e) => setShowSizePrices(e.target.checked)} />
                  Some sizes have a different price
                </label>
                {showSizePrices && (
                  <div id="field-sizePrices" className="mt-3 space-y-2.5">
                    <p className="text-sm text-charcoal/65">Leave a size empty to use the normal price{f.price ? ` (₹${Number(f.price).toLocaleString('en-IN')})` : ''}.</p>
                    {orderedSizes.map((s) => (
                      <div key={s} className="flex items-center gap-3">
                        <span className="w-20 shrink-0 text-sm font-semibold">{s}</span>
                        <div className="relative flex-1">
                          <span className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-charcoal/50">₹</span>
                          <input className="input pl-8" inputMode="numeric" aria-label={`Price for size ${s}`} placeholder={f.price || 'Same as price'} value={f.sizePrices[s] ?? ''} onChange={(e) => set('sizePrices', { ...f.sizePrices, [s]: digitsOnly(e.target.value) })} />
                        </div>
                      </div>
                    ))}
                    {errors.sizePrices && <p className="error-text" role="alert">{errors.sizePrices}</p>}
                  </div>
                )}
              </div>
            )}
          </div>
        </Section>

        <Section n={6} title="Show on website">
          <div className="space-y-4">
            <div className="flex items-center justify-between gap-4 rounded-xl bg-cream/60 p-4">
              <div>
                <p className="font-semibold text-burgundy">Available to buy</p>
                <p className="text-sm text-charcoal/65">{f.available ? 'Customers can add it to their cart.' : 'Shown as “SOLD OUT”. Customers cannot order it.'}</p>
              </div>
              <Switch checked={f.available} onChange={(v) => set('available', v)} label="Available to buy" />
            </div>
            <label className="flex min-h-[44px] cursor-pointer items-center gap-3"><input type="checkbox" className={check} checked={f.newArrival} onChange={(e) => set('newArrival', e.target.checked)} /> <span>Show in the <strong>New Arrivals</strong> section</span></label>
            <label className="flex min-h-[44px] cursor-pointer items-center gap-3"><input type="checkbox" className={check} checked={f.bestSeller} onChange={(e) => set('bestSeller', e.target.checked)} /> <span>Show in <strong>Customer Favourites</strong></span></label>
            <Field label="Label on the photo" htmlFor="badge" hint="A small tag shown on the product photo.">
              <select id="badge" className="input sm:max-w-xs" value={f.badge} onChange={(e) => set('badge', e.target.value)}>
                <option value="">No label</option>
                <option value="NEW">NEW</option>
                <option value="BEST SELLER">BEST SELLER</option>
                <option value="SALE">SALE</option>
              </select>
            </Field>
          </div>
        </Section>

        {editingId && (
          <div className="rounded-2xl border border-red-200 bg-red-50/60 p-5">
            <p className="font-semibold text-red-800">Delete this product</p>
            <p className="mt-1 text-sm text-red-900/80">Removes it from your website for good. If you only want to stop selling it for now, switch off “Available to buy” above instead.</p>
            <button type="button" className="btn-secondary btn-sm mt-3 text-red-700 hover:!border-red-400" onClick={() => setConfirmDelete(true)}><Icon name="trash" className="h-4 w-4" /> Delete product</button>
          </div>
        )}
      </div>

      <div className="sticky bottom-0 z-20 -mx-4 mt-6 border-t border-beige bg-white/95 px-4 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-3 backdrop-blur md:mx-0 md:rounded-2xl md:border">
        <div className="flex gap-3">
          <button type="button" className="btn-secondary flex-1 sm:flex-none" onClick={cancel} disabled={busy}>Cancel</button>
          <button type="button" className="btn-primary flex-[2] sm:flex-none sm:px-10" onClick={save} disabled={busy}>{busy && <Spinner className="h-4 w-4" />} Save Product</button>
        </div>
      </div>

      {confirmDelete && existing && (
        <ConfirmDialog title="Delete this product?" confirmLabel="Yes, delete product" busy={busy} onConfirm={remove} onCancel={() => setConfirmDelete(false)}
          message={<p><strong>{existing.name}</strong> will be removed from your website, including its photos. This cannot be undone.</p>} />
      )}
    </div>
  );
}
