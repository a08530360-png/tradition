import { useData } from '../data';
import { Icon, PageHeader, formatINR } from '../ui';
import { Link } from '../nav';

export default function Dashboard() {
  const { data } = useData();
  const { products, categories, settings } = data;
  const soldOut = products.filter((p) => p.available === false).length;
  const recent = products.slice(0, 5);
  const realCategories = categories.filter((c) => !c.system);

  const stat = 'card flex flex-col p-5';

  return (
    <div>
      <PageHeader title="Dashboard" subtitle="A quick look at your store." />

      <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
        <Link to="/products" className={`${stat} transition hover:border-gold`}>
          <span className="text-sm font-semibold text-charcoal/60">Total Products</span>
          <span className="mt-1 font-display text-4xl font-semibold text-burgundy">{products.length}</span>
        </Link>
        <Link to="/categories" className={`${stat} transition hover:border-gold`}>
          <span className="text-sm font-semibold text-charcoal/60">Total Categories</span>
          <span className="mt-1 font-display text-4xl font-semibold text-burgundy">{realCategories.length}</span>
        </Link>
        <Link to="/products" className={`${stat} transition hover:border-gold`}>
          <span className="text-sm font-semibold text-charcoal/60">Sold out</span>
          <span className="mt-1 font-display text-4xl font-semibold text-burgundy">{soldOut}</span>
        </Link>
        <Link to="/settings" className={`${stat} transition hover:border-gold`}>
          <span className="text-sm font-semibold text-charcoal/60">WhatsApp number</span>
          {settings.whatsappNumber ? (
            <span className="mt-2 break-all text-lg font-semibold text-burgundy">+{settings.whatsappNumber}</span>
          ) : (
            <span className="mt-2 text-sm font-semibold text-amber-700">Not set yet – tap to add</span>
          )}
        </Link>
      </div>

      <div className="mt-6 grid gap-3 sm:grid-cols-2">
        <Link to="/products/new" className="btn-primary min-h-[56px] text-base"><Icon name="plus" /> Add Product</Link>
        <Link to="/categories?new=1" className="btn-secondary min-h-[56px] text-base"><Icon name="plus" /> Add Category</Link>
      </div>

      <section className="mt-10">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-display text-2xl font-semibold text-burgundy">Latest products</h2>
          <Link to="/products" className="text-sm font-semibold text-maroon underline underline-offset-4">See all</Link>
        </div>
        {recent.length === 0 ? (
          <p className="card p-6 text-center text-charcoal/65">No products yet. Add your first product to get started.</p>
        ) : (
          <ul className="card divide-y divide-beige/70">
            {recent.map((p) => (
              <li key={p.id}>
                <Link to={`/products/${p.id}`} className="flex items-center gap-3 p-3 hover:bg-cream/60">
                  <img src={p.image} alt="" className="h-16 w-12 shrink-0 rounded-lg object-cover" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-semibold text-burgundy">{p.name}</p>
                    <p className="text-sm text-charcoal/60">{categories.find((c) => c.id === p.category)?.name ?? p.category}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">{formatINR(p.price)}</p>
                    {p.available === false && <p className="text-xs font-semibold text-red-700">Sold out</p>}
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
