import { useEffect, useState } from 'react';
import { api } from '../api';
import { useData } from '../data';
import { Link, useRoute } from '../nav';
import { ConfirmDialog, Field, Icon, Modal, PageHeader, Spinner, useToast } from '../ui';
import { SinglePhoto } from '../components/Photos';
import type { Category, FieldErrors } from '../types';

function CategoryForm({ category, onClose }: { category: Category | null; onClose: () => void }) {
  const { setData } = useData();
  const toast = useToast();
  const [name, setName] = useState(category?.name ?? '');
  const [image, setImage] = useState(category?.image ?? '');
  const [errors, setErrors] = useState<FieldErrors>({});
  const [busy, setBusy] = useState(false);

  const save = async () => {
    const e: FieldErrors = {};
    if (!name.trim()) e.name = 'Enter the category name.';
    else if (name.trim().length < 2) e.name = 'Category name must be at least 2 characters.';
    if (!image) e.image = 'Add a category photo.';
    setErrors(e);
    if (Object.keys(e).length) return;
    setBusy(true);
    try {
      setData(await api.saveCategory(category?.id ?? null, { name, image }));
      toast(category ? 'Category updated.' : 'Category added. It is now on your website.');
      onClose();
    } catch (err) {
      const ex = err as { fields?: FieldErrors; message: string };
      if (ex.fields) setErrors(ex.fields); else toast(ex.message, 'error');
    } finally { setBusy(false); }
  };

  return (
    <Modal title={category ? 'Edit category' : 'Add category'} onClose={busy ? () => {} : onClose}>
      <div className="space-y-5">
        <Field label="Category name" error={errors.name} htmlFor="cat-name">
          <input id="cat-name" className={`input ${errors.name ? 'input-error' : ''}`} value={name} maxLength={40} placeholder="e.g. Bridal Wear" onChange={(e) => setName(e.target.value)} autoFocus />
        </Field>
        <Field label="Category photo" error={undefined}>
          <SinglePhoto image={image} onChange={setImage} error={errors.image} />
        </Field>
        <div className="flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
          <button type="button" className="btn-secondary" onClick={onClose} disabled={busy}>Cancel</button>
          <button type="button" className="btn-primary" onClick={save} disabled={busy}>{busy && <Spinner className="h-4 w-4" />} Save category</button>
        </div>
      </div>
    </Modal>
  );
}

export default function Categories() {
  const { data, setData } = useData();
  const route = useRoute();
  const toast = useToast();
  const [editing, setEditing] = useState<Category | 'new' | null>(route.query.get('new') ? 'new' : null);
  const [deleting, setDeleting] = useState<Category | null>(null);
  const [blocked, setBlocked] = useState<Category | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => { if (route.query.get('new')) { setEditing('new'); window.history.replaceState(null, '', '#/categories'); } }, [route]);

  const countFor = (c: Category) => (c.system ? data.products.filter((p) => p.newArrival).length : data.products.filter((p) => p.category === c.id).length);

  const move = async (index: number, dir: -1 | 1) => {
    const order = data.categories.map((c) => c.id);
    [order[index], order[index + dir]] = [order[index + dir], order[index]];
    try { setData(await api.reorderCategories(order)); } catch (e) { toast((e as Error).message, 'error'); }
  };

  const remove = async () => {
    if (!deleting) return;
    setBusy(true);
    try { setData(await api.deleteCategory(deleting.id)); toast('Category deleted.'); setDeleting(null); }
    catch (e) { toast((e as Error).message, 'error'); setDeleting(null); }
    finally { setBusy(false); }
  };

  return (
    <div>
      <PageHeader
        title="Categories"
        subtitle="These are the “Shop by Category” cards on your website."
        actions={<button type="button" className="btn-primary" onClick={() => setEditing('new')}><Icon name="plus" /> Add Category</button>}
      />

      <ul className="grid gap-4 sm:grid-cols-2">
        {data.categories.map((c, i) => {
          const items = c.system ? data.products.filter((p) => p.newArrival) : data.products.filter((p) => p.category === c.id);
          return (
            <li key={c.id} className="card flex flex-col p-4">
              <div className="flex gap-4">
                <img src={c.image} alt="" className="h-28 w-[84px] shrink-0 rounded-xl bg-beige object-cover" />
                <div className="min-w-0 flex-1">
                  <h2 className="truncate font-display text-xl font-semibold text-burgundy">{c.name}</h2>
                  <p className="text-sm text-charcoal/65">{countFor(c)} product{countFor(c) === 1 ? '' : 's'}</p>
                  {c.system && <p className="mt-1 inline-block rounded-full bg-cream px-2.5 py-0.5 text-xs font-semibold text-burgundy">Special section</p>}
                  <div className="mt-3 flex gap-1.5">
                    <button type="button" className="btn-secondary btn-sm !px-3" disabled={i === 0} onClick={() => move(i, -1)} aria-label={`Move ${c.name} up`} title="Show earlier"><Icon name="up" className="h-4 w-4" /></button>
                    <button type="button" className="btn-secondary btn-sm !px-3" disabled={i === data.categories.length - 1} onClick={() => move(i, 1)} aria-label={`Move ${c.name} down`} title="Show later"><Icon name="down" className="h-4 w-4" /></button>
                  </div>
                </div>
              </div>

              {items.length > 0 && (
                <details className="mt-3 rounded-xl bg-cream/60 px-3 py-2 text-sm">
                  <summary className="min-h-[36px] cursor-pointer select-none py-1.5 font-semibold text-burgundy">Show products in this category</summary>
                  <ul className="mb-1 mt-1 space-y-1">
                    {items.map((p) => (
                      <li key={p.id}><Link to={`/products/${p.id}`} className="flex min-h-[40px] items-center gap-2 rounded-lg px-1 hover:bg-white"><img src={p.image} alt="" className="h-9 w-7 rounded object-cover" /><span className="truncate">{p.name}</span></Link></li>
                    ))}
                  </ul>
                </details>
              )}

              <div className="mt-4 flex flex-wrap gap-2">
                {!c.system && <Link to={`/products/new?category=${c.id}`} className="btn-secondary btn-sm"><Icon name="plus" className="h-4 w-4" /> Add product</Link>}
                {!c.system && items.length > 0 && <Link to={`/products?category=${c.id}`} className="btn-secondary btn-sm">View products</Link>}
                <button type="button" className="btn-secondary btn-sm" onClick={() => setEditing(c)}><Icon name="pencil" className="h-4 w-4" /> Edit</button>
                {!c.system && (
                  <button type="button" className="btn-secondary btn-sm text-red-700 hover:!border-red-400" onClick={() => (countFor(c) > 0 ? setBlocked(c) : setDeleting(c))}>
                    <Icon name="trash" className="h-4 w-4" /> Delete
                  </button>
                )}
              </div>
            </li>
          );
        })}
      </ul>

      {editing && <CategoryForm category={editing === 'new' ? null : editing} onClose={() => setEditing(null)} />}

      {blocked && (
        <Modal title="This category has products" onClose={() => setBlocked(null)}>
          <p className="text-[15px] leading-relaxed text-charcoal/80">
            “{blocked.name}” still contains {countFor(blocked)} product{countFor(blocked) === 1 ? '' : 's'}. To keep your customers from losing products by accident, a category can only be deleted when it is empty.
          </p>
          <p className="mt-3 text-[15px] leading-relaxed text-charcoal/80">Move those products to another category (or delete them) and then delete this category.</p>
          <div className="mt-6 flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
            <button type="button" className="btn-secondary" onClick={() => setBlocked(null)}>Close</button>
            <Link to={`/products?category=${blocked.id}`} className="btn-primary">View these products</Link>
          </div>
        </Modal>
      )}

      {deleting && (
        <ConfirmDialog
          title={`Delete “${deleting.name}”?`}
          confirmLabel="Yes, delete category"
          busy={busy}
          onConfirm={remove}
          onCancel={() => setDeleting(null)}
          message={
            <>
              <p>This category will be removed from your website. This cannot be undone.</p>
              {deleting.menuLinked && (
                <p className="mt-3 rounded-xl bg-amber-50 p-3 text-sm text-amber-900">
                  <strong>Heads up:</strong> your website’s top menu or footer has a link to this category. After deleting it, that link will show “No styles match”.
                </p>
              )}
            </>
          }
        />
      )}
    </div>
  );
}
