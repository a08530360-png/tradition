// Photo helpers for the browser: validate, shrink (fast uploads on mobile data), then upload.
import { api } from './api';

export const ACCEPT = 'image/jpeg,image/png,image/webp'; // iPhones convert HEIC to JPEG automatically with this list
const TYPES = new Set(['image/jpeg', 'image/png', 'image/webp']);
export const MAX_MB = 10;

export function checkFile(file: File): string {
  if (!TYPES.has(file.type)) return `"${file.name}" is not a JPG, PNG or WebP photo.`;
  if (file.size > MAX_MB * 1024 * 1024) return `"${file.name}" is larger than ${MAX_MB} MB.`;
  return '';
}

/** Shrinks big phone photos before upload. If anything goes wrong the original file is used. */
async function shrink(file: File): Promise<File> {
  try {
    if (file.size < 600 * 1024) return file;
    const bmp = await createImageBitmap(file, { imageOrientation: 'from-image' });
    const scale = Math.min(1, 1600 / Math.max(bmp.width, bmp.height));
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(bmp.width * scale);
    canvas.height = Math.round(bmp.height * scale);
    const ctx = canvas.getContext('2d');
    if (!ctx) return file;
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(bmp, 0, 0, canvas.width, canvas.height);
    const blob: Blob | null = await new Promise((r) => canvas.toBlob(r, 'image/jpeg', 0.86));
    return blob && blob.size < file.size ? new File([blob], file.name.replace(/\.\w+$/, '') + '.jpg', { type: 'image/jpeg' }) : file;
  } catch {
    return file;
  }
}

/** Validates, shrinks and uploads. Returns the stored image URLs, or throws an Error with a friendly message. */
export async function uploadPhotos(files: File[]): Promise<string[]> {
  for (const f of files) {
    const problem = checkFile(f);
    if (problem) throw new Error(problem);
  }
  return api.upload(await Promise.all(files.map(shrink)));
}
