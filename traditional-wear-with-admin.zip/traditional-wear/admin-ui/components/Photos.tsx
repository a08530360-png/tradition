import { useRef, useState } from 'react';
import { ACCEPT, uploadPhotos } from '../images';
import { Icon, Spinner } from '../ui';

const errMsg = (e: unknown) => (e instanceof Error ? e.message : 'Upload failed. Please try again.');

/** Several photos for a product: add, preview, replace, remove, re-order. The first photo is the main one. */
export function PhotoGrid({ images, onChange, max = 8, error }: { images: string[]; onChange: (next: string[]) => void; max?: number; error?: string }) {
  const addRef = useRef<HTMLInputElement>(null);
  const replaceRef = useRef<HTMLInputElement>(null);
  const replaceAt = useRef(0);
  const [busy, setBusy] = useState(0); // number of photos currently uploading
  const [msg, setMsg] = useState('');

  const add = async (files: FileList | null) => {
    if (!files?.length) return;
    setMsg('');
    let list = Array.from(files);
    const room = max - images.length;
    if (list.length > room) { setMsg(`You can add up to ${max} photos. Only the first ${room} were added.`); list = list.slice(0, Math.max(0, room)); }
    if (!list.length) return;
    setBusy(list.length);
    try { onChange([...images, ...(await uploadPhotos(list))]); } catch (e) { setMsg(errMsg(e)); } finally { setBusy(0); }
  };
  const replace = async (files: FileList | null) => {
    if (!files?.length) return;
    setMsg(''); setBusy(1);
    try { const [url] = await uploadPhotos([files[0]]); onChange(images.map((u, i) => (i === replaceAt.current ? url : u))); } catch (e) { setMsg(errMsg(e)); } finally { setBusy(0); }
  };
  const move = (i: number, d: -1 | 1) => {
    const next = [...images]; const j = i + d;
    [next[i], next[j]] = [next[j], next[i]];
    onChange(next);
  };

  const iconBtn = 'flex h-10 flex-1 items-center justify-center rounded-lg border border-beige bg-white text-burgundy transition hover:border-gold disabled:opacity-30';

  return (
    <div>
      <input ref={addRef} type="file" accept={ACCEPT} multiple className="hidden" onChange={(e) => { void add(e.target.files); e.target.value = ''; }} />
      <input ref={replaceRef} type="file" accept={ACCEPT} className="hidden" onChange={(e) => { void replace(e.target.files); e.target.value = ''; }} />

      <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
        {images.map((src, i) => (
          <li key={src} className="flex flex-col gap-2">
            <div className="relative aspect-[3/4] overflow-hidden rounded-xl bg-beige">
              <img src={src} alt={`Product photo ${i + 1}`} className="h-full w-full object-cover" />
              {i === 0 && <span className="absolute left-2 top-2 flex items-center gap-1 rounded-full bg-maroon px-2.5 py-1 text-[11px] font-semibold text-ivory"><Icon name="star" className="h-3 w-3" /> Main photo</span>}
            </div>
            <div className="flex gap-1.5">
              <button type="button" className={iconBtn} disabled={i === 0} onClick={() => move(i, -1)} aria-label={`Move photo ${i + 1} earlier`} title="Move earlier"><Icon name="left" className="h-4 w-4" /></button>
              <button type="button" className={iconBtn} disabled={i === images.length - 1} onClick={() => move(i, 1)} aria-label={`Move photo ${i + 1} later`} title="Move later"><Icon name="right" className="h-4 w-4" /></button>
              <button type="button" className={iconBtn} onClick={() => { replaceAt.current = i; replaceRef.current?.click(); }} aria-label={`Replace photo ${i + 1}`} title="Replace this photo"><Icon name="replace" className="h-4 w-4" /></button>
              <button type="button" className={`${iconBtn} text-red-700 hover:border-red-400`} onClick={() => onChange(images.filter((_, k) => k !== i))} aria-label={`Remove photo ${i + 1}`} title="Remove this photo"><Icon name="trash" className="h-4 w-4" /></button>
            </div>
          </li>
        ))}

        {Array.from({ length: busy }).map((_, i) => (
          <li key={`busy-${i}`} className="flex aspect-[3/4] items-center justify-center rounded-xl bg-beige/60 text-maroon"><Spinner className="h-7 w-7" /></li>
        ))}

        {images.length + busy < max && (
          <li>
            <button type="button" onClick={() => addRef.current?.click()} disabled={busy > 0}
              className={`flex aspect-[3/4] w-full flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed px-3 text-center text-sm font-semibold text-maroon transition hover:bg-cream disabled:opacity-50 ${error ? 'border-red-400' : 'border-gold/70'}`}>
              <Icon name="upload" className="h-7 w-7" />
              {images.length === 0 ? 'Add photos' : 'Add more'}
              <span className="text-xs font-normal text-charcoal/55">Camera or gallery</span>
            </button>
          </li>
        )}
      </ul>
      {msg && <p className="error-text" role="alert">{msg}</p>}
      {error && <p className="error-text" role="alert">{error}</p>}
      <p className="hint">The first photo is shown on the website. Use the arrows to change the order. JPG, PNG or WebP, up to 10 MB each. Upright (portrait) photos look best.</p>
    </div>
  );
}

/** One photo (used for categories). */
export function SinglePhoto({ image, onChange, error }: { image: string; onChange: (url: string) => void; error?: string }) {
  const ref = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');

  const pick = async (files: FileList | null) => {
    if (!files?.length) return;
    setMsg(''); setBusy(true);
    try { const [url] = await uploadPhotos([files[0]]); onChange(url); } catch (e) { setMsg(errMsg(e)); } finally { setBusy(false); }
  };

  return (
    <div>
      <input ref={ref} type="file" accept={ACCEPT} className="hidden" onChange={(e) => { void pick(e.target.files); e.target.value = ''; }} />
      <div className="flex items-center gap-4">
        <div className={`flex h-36 w-28 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-beige ${error ? 'ring-2 ring-red-400' : ''}`}>
          {busy ? <Spinner className="h-7 w-7 text-maroon" /> : image ? <img src={image} alt="Category" className="h-full w-full object-cover" /> : <Icon name="image" className="h-8 w-8 text-charcoal/30" />}
        </div>
        <div>
          <button type="button" className="btn-secondary btn-sm" onClick={() => ref.current?.click()} disabled={busy}>
            <Icon name={image ? 'replace' : 'upload'} className="h-4 w-4" /> {image ? 'Change photo' : 'Choose photo'}
          </button>
          <p className="hint">JPG, PNG or WebP, up to 10 MB.</p>
        </div>
      </div>
      {(msg || error) && <p className="error-text" role="alert">{msg || error}</p>}
    </div>
  );
}
