import { useEffect, useState, type AnchorHTMLAttributes, type ReactNode } from 'react';

// Tiny hash router: every admin screen lives under /admin#/something, so the server only needs to serve one page.
export interface Route { parts: string[]; query: URLSearchParams }

const parse = (): Route => {
  const raw = window.location.hash.replace(/^#\/?/, '');
  const [path, qs = ''] = raw.split('?');
  return { parts: path.split('/').filter(Boolean), query: new URLSearchParams(qs) };
};

export function useRoute(): Route {
  const [route, setRoute] = useState<Route>(parse);
  useEffect(() => {
    const on = () => { setRoute(parse()); window.scrollTo(0, 0); };
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);
  return route;
}

// A screen with unsaved changes can ask "are you sure?" before the admin navigates away from it.
let guard: (() => boolean) | null = null;
export const setNavGuard = (fn: (() => boolean) | null) => { guard = fn; };

export function go(to: string) {
  if (guard && !guard()) return;
  window.location.hash = to;
}

export function Link({ to, children, ...rest }: { to: string; children: ReactNode } & Omit<AnchorHTMLAttributes<HTMLAnchorElement>, 'href'>) {
  return (
    <a
      href={`#${to}`}
      {...rest}
      onClick={(e) => {
        if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
        e.preventDefault();
        go(to);
      }}
    >
      {children}
    </a>
  );
}
