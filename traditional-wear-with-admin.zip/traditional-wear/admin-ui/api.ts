import type { AdminData, Product } from './types';

export class ApiError extends Error {
  status: number;
  fields?: Record<string, string>;
  constructor(status: number, message: string, fields?: Record<string, string>) {
    super(message);
    this.status = status;
    this.fields = fields;
  }
}

let onUnauthorized: () => void = () => {};
export const setUnauthorizedHandler = (fn: () => void) => { onUnauthorized = fn; };

async function request<T>(method: string, url: string, body?: unknown): Promise<T> {
  let res: Response;
  try {
    res = await fetch(url, {
      method,
      credentials: 'same-origin',
      headers: { 'X-Requested-With': 'tw-admin', ...(body !== undefined && !(body instanceof FormData) ? { 'Content-Type': 'application/json' } : {}) },
      body: body === undefined ? undefined : body instanceof FormData ? body : JSON.stringify(body),
    });
  } catch {
    throw new ApiError(0, 'Cannot reach the server. Check your internet connection and try again.');
  }
  let data: any = null;
  try { data = await res.json(); } catch { /* not JSON */ }
  if (!res.ok) {
    if (res.status === 401 && !url.endsWith('/login') && !url.endsWith('/session')) onUnauthorized();
    throw new ApiError(res.status, data?.error || 'Something went wrong. Please try again.', data?.fields);
  }
  return data as T;
}

export interface SessionInfo { configured: boolean; problem: string; authenticated: boolean; username: string | null }

export const api = {
  session: () => request<SessionInfo>('GET', '/api/admin/session'),
  login: (username: string, password: string) => request<{ ok: true }>('POST', '/api/admin/login', { username, password }),
  logout: () => request<{ ok: true }>('POST', '/api/admin/logout'),
  data: () => request<AdminData>('GET', '/api/admin/data'),

  saveCategory: (id: string | null, body: { name: string; image: string }) =>
    id ? request<AdminData>('PUT', `/api/admin/categories/${id}`, body) : request<AdminData>('POST', '/api/admin/categories', body),
  deleteCategory: (id: string) => request<AdminData>('DELETE', `/api/admin/categories/${id}`),
  reorderCategories: (order: string[]) => request<AdminData>('POST', '/api/admin/categories/reorder', { order }),

  saveProduct: (id: number | null, body: unknown) =>
    id ? request<AdminData & { product: Product }>('PUT', `/api/admin/products/${id}`, body) : request<AdminData & { product: Product }>('POST', '/api/admin/products', body),
  deleteProduct: (id: number) => request<AdminData>('DELETE', `/api/admin/products/${id}`),
  setAvailability: (id: number, available: boolean) => request<AdminData>('PATCH', `/api/admin/products/${id}/availability`, { available }),

  saveSettings: (whatsappNumber: string) => request<AdminData>('PUT', '/api/admin/settings', { whatsappNumber }),

  upload: async (files: File[]) => {
    const fd = new FormData();
    files.forEach((f) => fd.append('files', f, f.name));
    return (await request<{ urls: string[] }>('POST', '/api/admin/upload', fd)).urls;
  },
};
