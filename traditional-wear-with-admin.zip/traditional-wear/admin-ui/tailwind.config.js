// The admin panel has its own stylesheet build, so the customer website's CSS is not affected by it.
import base from '../tailwind.config.js';

/** @type {import('tailwindcss').Config} */
export default {
  ...base,
  content: ['./admin.html', './admin-ui/**/*.{ts,tsx}'],
  theme: {
    extend: {
      ...base.theme.extend,
      fontFamily: { display: ['Georgia', 'serif'], body: ['system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'sans-serif'] },
    },
  },
};
