import { useCallback, useEffect, useState } from 'react';
import { api, setUnauthorizedHandler, type SessionInfo } from './api';
import { DataCtx } from './data';
import { Icon, Spinner, ToastProvider, useToast } from './ui';
import { Link, go, useRoute } from './nav';
import type { AdminData } from './types';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Categories from './pages/Categories';
import Products from './pages/Products';
import ProductForm from './pages/ProductForm';
import Settings from './pages/Settings';

const NAV = [
  { to: '/dashboard', label: 'Dashboard', icon: 'home', match: 'dashboard' },
  { to: '/categories', label: 'Categories', icon: 'grid', match: 'categories' },
  { to: '/products', label: 'Products', icon: 'tag', match: 'products' },
  { to: '/settings', label: 'WhatsApp / Settings', short: 'Settings', icon: 'sliders', match: 'settings' },
] as const;

function Shell({ username, onLogout }: { username: string; onLogout: () => void }) {
  const route = useRoute();
  const section = route.parts[0] || 'dashboard';
  const isForm = section === 'products' && route.parts.length > 1; // add / edit product = focused screen

  let page;
  if (section === 'categories') page = <Categories />;
  else if (section === 'products' && route.parts[1]) page = <ProductForm key={route.parts[1]} route={route} />;
  else if (section === 'products') page = <Products route={route} />;
  else if (section === 'settings') page = <Settings />;
  else page = <Dashboard />;

  return (
    <div className="min-h-dvh md:pl-64">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col bg-burgundy text-ivory md:flex">
        <div className="px-6 pb-4 pt-7">
          <p className="font-display text-2xl font-semibold leading-tight">Traditional Wear</p>
          <p className="mt-1 text-xs tracking-[0.2em] text-gold-light">ADMIN PANEL</p>
        </div>
        <nav className="mt-4 flex-1 space-y-1 px-3" aria-label="Admin sections">
          {NAV.map((n) => (
            <Link key={n.to} to={n.to} aria-current={section === n.match ? 'page' : undefined}
              className={`flex min-h-[46px] items-center gap-3 rounded-xl px-4 text-sm font-semibold transition ${section === n.match ? 'bg-white/15 text-white' : 'text-ivory/75 hover:bg-white/10'}`}>
              <Icon name={n.icon} /> {n.label}
            </Link>
          ))}
        </nav>
        <div className="space-y-2 border-t border-white/10 p-4">
          <a href="/" target="_blank" rel="noopener noreferrer" className="flex min-h-[44px] items-center gap-3 rounded-xl px-3 text-sm text-ivory/80 hover:bg-white/10">
            <Icon name="external" /> View website
          </a>
          <button type="button" onClick={onLogout} className="flex min-h-[44px] w-full items-center gap-3 rounded-xl px-3 text-sm text-ivory/80 hover:bg-white/10">
            <Icon name="logout" /> Log out <span className="ml-auto truncate text-xs text-ivory/50">{username}</span>
          </button>
        </div>
      </aside>

      {/* Mobile top bar */}
      <header className="sticky top-0 z-30 flex h-14 items-center justify-between bg-burgundy px-4 pt-[env(safe-area-inset-top)] text-ivory md:hidden">
        <p className="font-display text-lg font-semibold">Traditional Wear <span className="text-xs font-normal tracking-widest text-gold-light">ADMIN</span></p>
        <div className="flex items-center">
          <a href="/" target="_blank" rel="noopener noreferrer" aria-label="View website" className="flex h-11 w-11 items-center justify-center"><Icon name="external" className="h-5 w-5" /></a>
          <button type="button" onClick={onLogout} aria-label="Log out" className="flex h-11 w-11 items-center justify-center"><Icon name="logout" className="h-5 w-5" /></button>
        </div>
      </header>

      <main className={`mx-auto max-w-5xl px-4 py-6 md:px-8 md:py-10 ${isForm ? 'pb-6' : 'pb-28'} md:pb-12`}>{page}</main>

      {/* Mobile bottom tabs */}
      {!isForm && (
        <nav className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-4 border-t border-beige bg-white pb-[env(safe-area-inset-bottom)] md:hidden" aria-label="Admin sections">
          {NAV.map((n) => (
            <Link key={n.to} to={n.to} aria-current={section === n.match ? 'page' : undefined}
              className={`flex min-h-[58px] flex-col items-center justify-center gap-0.5 text-[11px] font-semibold ${section === n.match ? 'text-maroon' : 'text-charcoal/55'}`}>
              <Icon name={n.icon} className="h-6 w-6" /> {'short' in n ? n.short : n.label}
            </Link>
          ))}
        </nav>
      )}
    </div>
  );
}

function Authenticated({ session, onLoggedOut }: { session: SessionInfo; onLoggedOut: (msg?: string) => void }) {
  const [data, setData] = useState<AdminData | null>(null);
  const [error, setError] = useState('');
  const toast = useToast();

  const reload = useCallback(async () => {
    try { setData(await api.data()); setError(''); } catch (e) { setError((e as Error).message); }
  }, []);
  useEffect(() => { void reload(); }, [reload]);

  const logout = async () => {
    try { await api.logout(); } catch { /* ignore */ }
    onLoggedOut();
    toast('You are logged out.');
  };

  if (error && !data) {
    return (
      <div className="flex min-h-dvh flex-col items-center justify-center gap-4 p-6 text-center">
        <p className="max-w-sm text-charcoal/80">{error}</p>
        <button type="button" className="btn-primary" onClick={() => { setError(''); void reload(); }}>Try again</button>
      </div>
    );
  }
  if (!data) return <div className="flex min-h-dvh items-center justify-center text-maroon"><Spinner className="h-8 w-8" /></div>;

  return (
    <DataCtx.Provider value={{ data, setData, reload }}>
      <Shell username={session.username || 'admin'} onLogout={logout} />
    </DataCtx.Provider>
  );
}

export default function App() {
  const [session, setSession] = useState<SessionInfo | null>(null);
  const [notice, setNotice] = useState('');
  const [fatal, setFatal] = useState('');

  const refreshSession = useCallback(async () => {
    try { setSession(await api.session()); } catch (e) { setFatal((e as Error).message); }
  }, []);
  useEffect(() => {
    void refreshSession();
    setUnauthorizedHandler(() => { setNotice('Your session ended. Please sign in again.'); setSession((s) => (s ? { ...s, authenticated: false } : s)); });
  }, [refreshSession]);
  useEffect(() => { if (session && !session.authenticated) go('/dashboard'); }, [session]);

  let body;
  if (fatal) body = <div className="flex min-h-dvh items-center justify-center p-6 text-center text-charcoal/80">{fatal}</div>;
  else if (!session) body = <div className="flex min-h-dvh items-center justify-center text-maroon"><Spinner className="h-8 w-8" /></div>;
  else if (!session.authenticated) body = <Login session={session} notice={notice} onSuccess={() => { setNotice(''); void refreshSession(); }} />;
  else body = <Authenticated session={session} onLoggedOut={(msg) => { setNotice(msg || ''); setSession((s) => (s ? { ...s, authenticated: false } : s)); }} />;

  return <ToastProvider>{body}</ToastProvider>;
}
