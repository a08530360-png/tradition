import type { Product, ProductColor } from '../src/types';

export type { Product, ProductColor };

export interface Category { id: string; name: string; image: string; system?: boolean; menuLinked?: boolean }
export interface Settings { whatsappNumber: string }
export interface AdminData { settings: Settings; categories: Category[]; products: Product[] }
export type FieldErrors = Record<string, string>;
